
public class SBIBanking implements Banking {

	@Override
	public void depositCash() {
		// TODO Auto-generated method stub
		System.out.println("Depositing As per the rules of SBI");
	}

	@Override
	public void withdrawCash() {
		// TODO Auto-generated method stub
		System.out.println("Withdrawing As per the rules of SBI");
	}

	@Override
	public void checkBalance() {
		// TODO Auto-generated method stub
		System.out.println("Balance as Per SBI Guidelines");
	}

}
