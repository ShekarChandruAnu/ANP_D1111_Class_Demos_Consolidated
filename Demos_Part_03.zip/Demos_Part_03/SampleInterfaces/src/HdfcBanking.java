
public class HdfcBanking implements Banking {

	@Override
	public void depositCash() {
		// TODO Auto-generated method stub
		System.out.println(" Depositing Cash ... As  per HDFC Guidelines");
	}

	@Override
	public void withdrawCash() {
		// TODO Auto-generated method stub
		System.out.println("Withdrawing Cash as per HDFC Guidelines");
	}

	@Override
	public void checkBalance() {
		// TODO Auto-generated method stub
		System.out.println("Checking Balance and Balance rules are as per HDFC guidelines");
	}

}
