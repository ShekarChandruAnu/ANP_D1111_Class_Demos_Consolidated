
public class AccountHolderClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Banking acctHolder ;
		acctHolder = new SBIBanking();
		acctHolder.depositCash();
		acctHolder.withdrawCash();
		acctHolder.checkBalance();
		System.out.println("----------");
		acctHolder = new HdfcBanking();
		acctHolder.depositCash();
		acctHolder.withdrawCash();
		acctHolder.checkBalance();

	}

}
