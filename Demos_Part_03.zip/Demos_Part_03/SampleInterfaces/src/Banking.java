
public interface Banking {
	
	public void depositCash();
	public void withdrawCash();
	public void checkBalance();
}
