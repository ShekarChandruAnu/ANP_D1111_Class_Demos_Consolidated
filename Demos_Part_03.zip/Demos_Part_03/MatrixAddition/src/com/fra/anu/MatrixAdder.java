package com.fra.anu;

public class MatrixAdder {

	public int[][] add2Dmatrices(int[][] arr1,int[][] arr2)
	{
		int resultArray[][] = new int[3][3];
		
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				resultArray[i][j] = arr1[i][j]+arr2[i][j];
			}
		}
		
		return resultArray;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MatrixAdder	mart = new MatrixAdder();
		int[][] arra = {{10,20,30},{100,200,300},{1000,2000,3000}};
		
		int[][] arrb = {{15,25,35},{150,250,350},{1500,2500,3500}};
		int myResult[][] = mart.add2Dmatrices(arra, arrb);
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				System.out.print(myResult[i][j]+" ");
			}
			System.out.println();
		}

	}

}
