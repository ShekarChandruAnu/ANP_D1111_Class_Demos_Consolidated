package com.nonfra.anu;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

public class HashtableSample {

	Hashtable <String,Employee> hashTable = new Hashtable<String,Employee>();
	public void populateHashTable()
	{
		hashTable.put("E001", new Employee ("E001","Kiran Kumar","RTNagar",10000,12.3f));
		hashTable.put("E003", new Employee ("E003","Kishan Kumar","Wilson Garden",12000,12.3f));
		hashTable.put("E006", new Employee ("E006","Mohan Kumar","Koramangala",13000,11.3f));
		hashTable.put("E005", new Employee ("E005","Mithila Kumar","Vijayanagar",14000,13.3f));
		hashTable.put("E002", new Employee ("E002","Madan","Malleswaram",11000,10.3f));
		hashTable.put("E004", new Employee ("E004","Keerthana","Rajajinagar",9000,13.3f));
		
	}
	public void fetchHashTableObjects()
	{
		Enumeration <String> myKeyEnumer = hashTable.keys();
		while(myKeyEnumer.hasMoreElements())
		{
			String myKey = myKeyEnumer.nextElement();
			System.out.println("The Value for the Key "+myKey+"  is "+hashTable.get(myKey));
			
		}
	}
	public void searchKeyInHashTable(String keyToSearch)
	{
		boolean flag = false;
		String searchedKey="";
		Set <String> myKeySet = hashTable.keySet();
		Iterator <String> myKeyIter = myKeySet.iterator();
		while(myKeyIter.hasNext())
		{
			String myKey = myKeyIter.next();
			if(myKey.equals(keyToSearch))
			{
				searchedKey = myKey;
				flag = true;
				break;
								// RECAP CRUD ARRAYLIST - delete /modify/add/read
			}					// Comparator/Comparable
		}
		System.out.println("The Key You Searched Exists "+searchedKey);
		if(flag)
		{
			Employee employee = hashTable.get(searchedKey);
			System.out.println("Hey the Employee Whose Key you gave exist "+employee);
		}
		else
		{
			System.out.println("Hey Sorry The Key You Search does not exist..");
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashtableSample hts = new HashtableSample();
		hts.populateHashTable();
		hts.fetchHashTableObjects();
	System.out.println("-------");
	hts.searchKeyInHashTable("E005");
	hts.searchKeyInHashTable("1000");

	}

}
