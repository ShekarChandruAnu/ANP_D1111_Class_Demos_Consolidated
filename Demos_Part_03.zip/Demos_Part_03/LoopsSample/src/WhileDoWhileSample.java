import java.util.Scanner;

public class WhileDoWhileSample {

	// ctrl+shift+o
	Scanner scan1 = new Scanner(System.in);
	public void sampleWhile()
	{
		String reply = "yes";
		int num,sqr;
		
		while(reply.equals("yes") || reply.equals("YES"))
		{
			System.out.println("Enter a Number");
			num = scan1.nextInt();
			sqr = num * num;
			System.out.println("The Square of your Number is "+sqr);
			System.out.println("Do You wish to continue yes/no");
			reply = scan1.next();
		}
		System.out.println("You are out of loop");
	}
	public void sampleWhileWithBreak()
	{
		String reply = "yes";
		int num,sqr;
		
		while(reply.equals("yes") || reply.equals("YES"))
		{
			System.out.println("Enter a Number");
			num = scan1.nextInt();
			if(num >= 100)
			{
				System.out.println("Sorry range should be less than or equal to 100");
				//break;
				continue;
			}
			sqr = num * num;
			System.out.println("The Square of your Number is "+sqr);
			System.out.println("Do You wish to continue yes/no");
			reply = scan1.next();
		}
		System.out.println("You are out of loop");
	}
	public void sampleDoWhile()
	{
		String reply = "yes";
		int num,sqr;
		
		do
		{
			System.out.println("Enter a Number");
			num = scan1.nextInt();
			sqr = num * num;
			System.out.println("The Square of your Number is "+sqr);
			System.out.println("Do You wish to continue yes/no");
			reply = scan1.next();
		}while(reply.equals("yes") || reply.equals("YES"));
		System.out.println("You are out of loop");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WhileDoWhileSample whiler = new WhileDoWhileSample();
		//whiler.sampleWhile();
		//whiler.sampleDoWhile();
		whiler.sampleWhileWithBreak();

	}

}
