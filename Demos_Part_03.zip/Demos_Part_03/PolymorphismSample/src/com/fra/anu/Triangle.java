package com.fra.anu;

public class Triangle extends Shapes{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Drawing Triangles..");
	}

}
