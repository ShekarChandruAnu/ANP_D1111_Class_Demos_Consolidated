package com.fra.anu;

public class Person {

	//Variables Declared
	String id;
	String personName;
	public void display1()
	{
		System.out.println("Displaying Person Basic Details...");
	}
	//Method doRoutineWork
	public void doRoutineWork()
	{
		System.out.println("Person carries out his basic day to day functionalities");
	}
}
