package com.fra.anu;

public class SoftwareEngineer extends Person{

	@Override
	public void doRoutineWork()
	{
		System.out.println("Software Engineer Performs Code-Software Development");
	}
	public void display2()
	{
		System.out.println("Displaying SoftwareEnginner Personal Details");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SoftwareEngineer sEngineer1 = new SoftwareEngineer();
		sEngineer1.display1();//calling parent class method display1
		sEngineer1.display2();//calling derived class method display2
		sEngineer1.doRoutineWork();// which base class method or Derived class method
	}

}
