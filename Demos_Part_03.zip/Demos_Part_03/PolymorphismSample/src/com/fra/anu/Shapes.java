package com.fra.anu;

public abstract class Shapes {

	public abstract void draw();
}
