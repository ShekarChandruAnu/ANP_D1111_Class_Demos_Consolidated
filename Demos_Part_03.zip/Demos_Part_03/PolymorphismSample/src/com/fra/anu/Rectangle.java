package com.fra.anu;

public class Rectangle extends Shapes{

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Drawing Rectangles....");
	}
	

}
