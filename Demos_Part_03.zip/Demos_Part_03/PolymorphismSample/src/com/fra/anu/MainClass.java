package com.fra.anu;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		 * Customer c1 = new Customer()
		 * c1 = new Student() 
		 * Student s1 = new Student()
		 * 
		 */
		
		Shapes sh;
		sh = new Rectangle();
		sh.draw();
		
		sh = new Triangle();
		sh.draw();
		/*
		 * int num1,num2;
		 * char ch;
		 * int *ptr; ptr = &num1;  ACCEPTED
		 *  ptr = &ch NOT ACCEPTED
		 * 
		 * 
		 */

	}

}
