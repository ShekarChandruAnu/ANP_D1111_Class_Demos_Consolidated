package com.fra.anu;

import java.util.Calendar;
import java.util.Date;

public class DateSampleLegacy {

	Date myDate = new Date();
	String[] months = {"January","February","March","April","May","June","July","August","September","October","November","December"};
	String[] days = {"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
	public void manipulateDate()
	{
		System.out.println("Date is :"+myDate.getDate());
		System.out.println("Day is :"+myDate.getDay());
		System.out.println("Day is :"+days[myDate.getDay()]);
		System.out.println("Month is :"+myDate.getMonth());
		System.out.println("Month in words "+months[myDate.getMonth()]);
		System.out.println("Year is :"+myDate.getYear());//125
		System.out.println("Year Correctly is :"+(myDate.getYear()+1900));
		System.out.println("Hour is "+myDate.getHours());
		System.out.println("Minute is "+myDate.getMinutes());
		System.out.println("Second is "+myDate.getSeconds());
		System.out.println("Time Lapsed in Milliseconds since 1970 Jan 01 00 Hrs :"+myDate.getTime());
		
	}
	public void manipulateCalendar()
	{
						//0	   1     2     3      4       5     6  7
		String[] days = {"","Sun","Mon","Tue","Wed","Thurs","Fri","Sat"};
		//					2		3	4		5	6		7	8		9    10   11      0   1       
		String[] months = {"Nov","Dec","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct"};
		Calendar cal = Calendar.getInstance();
		System.out.println(" Day Of The Week :"+Calendar.DAY_OF_WEEK); // 7 represents day of the week
		System.out.println("Day of the Month :"+Calendar.DAY_OF_MONTH);
		System.out.println("Month of the Year "+Calendar.MONTH);// 
		//cal.get(5)
		System.out.println("Day of the Year :"+Calendar.DAY_OF_YEAR);
		System.out.println("Hour of the Day :"+Calendar.HOUR_OF_DAY);
		System.out.println("Minute  :"+Calendar.MINUTE);
		System.out.println("Second :"+Calendar.SECOND);
		System.out.println("DAY_OF_WEEK_IN_MONTH :"+Calendar.DAY_OF_WEEK_IN_MONTH);
		System.out.println("WEEK_OF_YEAR :"+Calendar.WEEK_OF_YEAR);
		System.out.println("-----------------");
		System.out.println(" Day Of The Week :"+cal.get(Calendar.DAY_OF_WEEK));
	System.out.println(" Day Of The Week :"+days[cal.get(Calendar.DAY_OF_WEEK)]);
		System.out.println("Month of the Year :"+months[cal.get(Calendar.DAY_OF_MONTH)]);
		System.out.println("Day of the Year :"+cal.get(Calendar.DAY_OF_YEAR));
		System.out.println("Hour of the Day :"+cal.get(Calendar.HOUR_OF_DAY));
		System.out.println("Month Of the Year :"+cal.get(Calendar.MONTH));//cal.get(2)
		System.out.println("Minute  :"+cal.get(Calendar.MINUTE));
		System.out.println("Second :"+cal.get(Calendar.SECOND));
		System.out.println("DAY_OF_WEEK_IN_MONTH :"+cal.get(Calendar.DAY_OF_WEEK_IN_MONTH));
		System.out.println("WEEK_OF_YEAR :"+cal.get(Calendar.WEEK_OF_YEAR));
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DateSampleLegacy dsl = new DateSampleLegacy();
		//dsl.manipulateDate();
		dsl.manipulateCalendar();

	}

}
