package com.fra.anu;

public abstract class Shape {
	double area;
	public abstract void calculateArea(double side);
	public abstract void displayArea(); 

}
