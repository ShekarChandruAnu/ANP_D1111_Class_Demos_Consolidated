package com.fra.anu;

public class Triangle extends Shape{

	@Override
	public void calculateArea(double side) {
		// TODO Auto-generated method stub
		area = 0.5 * side * (1.5 * side);
	}

	@Override
	public void displayArea() {
		// TODO Auto-generated method stub
		System.out.println("The Area of the Triangle is "+area);
	}

}
