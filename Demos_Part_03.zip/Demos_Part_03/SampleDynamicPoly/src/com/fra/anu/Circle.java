package com.fra.anu;

public class Circle extends Shape{

	@Override
	public void calculateArea(double side) {
		// TODO Auto-generated method stub
		area = 3.14 * side * side;
	}

	@Override
	public void displayArea() {
		// TODO Auto-generated method stub
		System.out.println("The Area of the Circle is "+area);
	}

}
