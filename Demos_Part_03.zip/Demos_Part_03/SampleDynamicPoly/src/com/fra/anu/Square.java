package com.fra.anu;

public class Square extends Shape{

	@Override
	public void calculateArea(double side) {
		// TODO Auto-generated method stub
		area  = side * side;
	}

	@Override
	public void displayArea() {
		// TODO Auto-generated method stub
		System.out.println("The Area of the Square is "+area);
	}

}
