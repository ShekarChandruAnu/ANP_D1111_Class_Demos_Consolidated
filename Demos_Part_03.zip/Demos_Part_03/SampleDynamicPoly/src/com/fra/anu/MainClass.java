package com.fra.anu;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan1 = new Scanner(System.in);
		System.out.println("---------AREA CALCULATOR------------");
		System.out.println("1.Calculate Area of a Rectangle...");
		System.out.println("2.Calculate Area of a Triangle...");
		System.out.println("3.Calculate Area of a Circle...");
		System.out.println("4.Calculate Area of a Square...");
		String reply ="yes";
		double side;
		Shape shape;
		int choice;
		do 
		{
			System.out.println("Enter Your Choice...");
			choice = scan1.nextInt();
			switch(choice)
			{
				case 1:
				{
					shape = new Rectangle();
					System.out.println("Enter the Length of the Rectangle ");
					side = scan1.nextDouble();
					shape.calculateArea(side);
					shape.displayArea();
					break;
				}
				case 2:
				{
					shape = new Triangle();
					System.out.println("Enter the Base of the Triangle ");
					side = scan1.nextDouble();
					shape.calculateArea(side);
					shape.displayArea();
					break;
				}
				case 3:
				{
					shape = new Circle();
					System.out.println("Enter the Radius of the Circle ");
					side = scan1.nextDouble();
					shape.calculateArea(side);
					shape.displayArea();
					break;
				}
				case 4:
				{
					shape = new Square();
					System.out.println("Enter the Side of the Square ");
					side = scan1.nextDouble();
					shape.calculateArea(side);
					shape.displayArea();
					break;
				}
				default :
				{
					System.out.println("Sorry Valid Range is 1-4");
					break;
				}
		}
			System.out.println("Do You wish to continue calculating Areas yes/no");
			reply= scan1.next();
		}while(reply.equals("yes") || reply.equals("YES"));

	}

}
