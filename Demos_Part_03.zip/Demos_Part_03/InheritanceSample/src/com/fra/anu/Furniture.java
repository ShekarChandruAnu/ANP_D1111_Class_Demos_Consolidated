package com.fra.anu;

import java.util.Scanner;

public class Furniture {
	
	// Default within the package
	Scanner scan1 = new Scanner(System.in);
	protected int length;
	protected int width;
	protected int height;
	
	public Furniture()
	{
		length = 0;
		width = 0;
		height = 0;
	}
	
	public void acceptFurnitureDetails()
	{
		System.out.println("Enter the Length of the furniture");
		length = scan1.nextInt();
		System.out.println("Enter the Width of the Furniture");
		width = scan1.nextInt();
		System.out.println("Enter the height of the Furniture");
		height = scan1.nextInt();
		
	}
	
	public void displayFurnitureDetails()
	{
		System.out.println("The Furniture Details are");
		System.out.println("The Length is "+length);
		System.out.println("The Width is "+width);
		System.out.println("The Height is "+height);
	}



}
