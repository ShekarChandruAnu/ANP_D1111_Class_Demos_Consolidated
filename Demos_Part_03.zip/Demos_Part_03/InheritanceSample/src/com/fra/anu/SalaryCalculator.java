package com.fra.anu;

public class SalaryCalculator {

	double grossSalary;
	double nettSalary;
	public void calculateSalary(double basic,double hra,double cca,double allowance,String employeeName)
	{
		grossSalary = basic+hra+cca+allowance;
		System.out.println("The Gross Salary for "+employeeName+" is "+grossSalary);
	}
	public void calculateSalary(double grossSalary,double deductions,String employeeName)
	{
		nettSalary = grossSalary - deductions;
		System.out.println("The Nett Salary for Employee "+employeeName+" is "+nettSalary);
	}
	public void calculateSalary(double basic,double hra,double cca,double allowance,double deductions,String employeeName)
	{
		grossSalary = basic+hra+cca+allowance;
		nettSalary = grossSalary - deductions;
		System.out.println("The Gross for the Employee "+employeeName+" is "+grossSalary);
		System.out.println("The Nett Salary for the Employee "+employeeName+"Is "+nettSalary);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SalaryCalculator sal = new SalaryCalculator();
		sal.calculateSalary(1000.0,250.0,350.0,250.0,"Harsha");
		sal.calculateSalary(4000.0, 350.0, "Kiran");
		sal.calculateSalary(2000.0, 250.0, 350.0, 450.0, 275.0, "Kumar");

	}

}
