package com.fra.anu;

public class Table {

	int no_Of_Legs;
	
	public void acceptTableDetails()
	{
		
	}
	public void displayTableDetails()
	{
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
