package com.fra.anu;

public class BookShelf extends Furniture{

	int no_Of_Shelves;
	
	public void acceptBookShelfDetails()
	{
		/*
		System.out.println("Enter the length ...");
		length = scan1.nextInt();
		System.out.println("Enter the Width ");
		width = scan1.nextInt();
		System.out.println("Enter the Height ");
		height = scan1.nextInt();*/
		//this 
		super.acceptFurnitureDetails();
		System.out.println("Enter the No Of Shelves");
		no_Of_Shelves = scan1.nextInt();
	}
	public void displayBookShelfDetails()
	{
		System.out.println("The Furniture details are");
	/*	System.out.println("The Length is "+length);
		System.out.println("The Width is "+width);
		System.out.println("The Height is "+height);*/
		super.displayFurnitureDetails();
		System.out.println("The No Of Shelves of the Book SHelf is "+no_Of_Shelves);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BookShelf shelf1 = new BookShelf();
		shelf1.acceptBookShelfDetails();
		shelf1.displayBookShelfDetails();

	}

}
