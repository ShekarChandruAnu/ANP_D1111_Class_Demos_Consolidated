package com.fra.anu;

//CONFIRMS vs CONFORMS
public class Student implements Comparable <Student> {
	// COMPARABLE CONFORMS TO
	String studentId;
	String studentName;
	String studentCity;
	int score;
	
	public Student() {
		super();
	}
	public Student(String studentId, String studentName, String studentCity, int score) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentCity = studentCity;
		this.score = score;
	}
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentCity() {
		return studentCity;
	}
	public void setStudentCity(String studentCity) {
		this.studentCity = studentCity;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", studentCity=" + studentCity
				+ ", score=" + score + "]";
	}
	
	
	
	//StudentID Sorting
/*	@Override
	public int compareTo(Student student) {
		// TODO Auto-generated method stub
		//str1.compareTo(str2) > 0
		if(this.studentId.compareTo(student.studentId) > 0)
		{
			return 1;
		}
		else if(this.studentId.compareTo(student.studentId)<0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}*/
	
	//StudentName Sorting
/*	@Override
	public int compareTo(Student student) {
		// TODO Auto-generated method stub
		if(this.studentName.compareTo(student.studentName) > 0)
		{
			return 1;
		}
		else if(this.studentName.compareTo(student.studentName) < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}*/
	@Override
	public int compareTo(Student student) {
		// TODO Auto-generated method stub
		if(this.score > student.score)
		{
			return -1;
		}
		else if(this.score < student.score)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}

}
