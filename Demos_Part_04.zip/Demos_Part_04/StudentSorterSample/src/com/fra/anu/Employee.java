package com.fra.anu;

public class Employee {
	String employeeId;
	String employeeCity;
	String employeeName;
	String employeeAddress;
	int employeeSalary;
	
	public Employee() {
		super();
	}

	public Employee(String employeeId, String employeeCity, String employeeName, String employeeAddress,
			int employeeSalary) {
		super();
		this.employeeId = employeeId;
		this.employeeCity = employeeCity;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.employeeSalary = employeeSalary;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeCity() {
		return employeeCity;
	}

	public void setEmployeeCity(String employeeCity) {
		this.employeeCity = employeeCity;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeAddress() {
		return employeeAddress;
	}

	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}

	public int getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(int employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeCity=" + employeeCity + ", employeeName="
				+ employeeName + ", employeeAddress=" + employeeAddress + ", employeeSalary=" + employeeSalary + "]";
	}
	
}

