package com.fra.anu;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class EmployeeSorter {

	public void sortEmployees()
	{
		ArrayList <Employee> employees = new ArrayList<Employee>();
		employees.add(new Employee("E003","Coimbatore","Kiran Kumar","Jayanagar",12000));
		employees.add(new Employee("E005","Ahmedabad","Amarendra","BhashyamCircle",15000));
		employees.add(new Employee("E002","Delhi","Giridhar","Eejipura",11000));
		employees.add(new Employee("E001","Faridabad","Faheem","Vijayanagar",10000));
		employees.add(new Employee("E004","Ernakulam","Emanuel","Koramangala",14000));
		
		System.out.println("Sorting Employee based on ID");
		Collections.sort(employees, new IdSorter());
		Iterator <Employee> empIter = employees.iterator();
		while(empIter.hasNext())
		{
			Employee employee = empIter.next();
			System.out.println(employee);
		}
		System.out.println("--------------------");
		System.out.println("Sorting Employee based on employee City");
		Collections.sort(employees,new CitySorter());
		Iterator <Employee> empCityIter = employees.iterator();
		while(empCityIter.hasNext())
		{
			Employee employee = empCityIter.next();
			System.out.println(employee);
		}
		System.out.println("--------------------");
		System.out.println("Sorting Employee based on employee Salary");
		Collections.sort(employees,new SalarySorter());
		Iterator <Employee> empSalIter = employees.iterator();
		while(empSalIter.hasNext())
		{
			Employee employee = empSalIter.next();
			System.out.println(employee);
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeSorter eSorter = new EmployeeSorter();
		eSorter.sortEmployees();

	}

}
