package com.fra.anu;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class StudentSorter {

	public void sortStudents()
	{
		
		ArrayList <Student> students = new ArrayList<Student>();
		students.add(new Student("S004","Daniel","Coimbatore",89));
		students.add(new Student("S005","Amarendra","Ernakulam",76));
		students.add(new Student("S002","Faheem","Faridabad",98));
		students.add(new Student("S001","Ganesh","Delhi",59));
		students.add(new Student("S003","Emanuel","Ahmedabad",66));
		
		Collections.sort(students);
		System.out.println("Students Sorted Based on Student Score");
		Iterator <Student> studIter = students.iterator();
		while(studIter.hasNext())
		{
			Student student = studIter.next();
			System.out.println(student);
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StudentSorter sSorter = new StudentSorter();
		sSorter.sortStudents();
		
	

	}

}
