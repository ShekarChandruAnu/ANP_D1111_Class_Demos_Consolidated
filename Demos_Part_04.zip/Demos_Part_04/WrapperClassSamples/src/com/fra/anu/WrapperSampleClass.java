package com.fra.anu;

public class WrapperSampleClass {
	
	//DEPRECATED 
	public void manipulateWrapperClasses()
	{
		float fltVar = 123.456f;
		System.out.println("The Primitive Typed float is :"+fltVar);
		Float fltObj = new Float(fltVar);
		//Converted into a Reference type Float from Value type-float
		System.out.println("The Boxed Object of float type is :"+fltObj);
		
		double dblVar = 1234456.678d;
		System.out.println("The Primitive Typed double is "+dblVar);
		Double dblObj = new Double(fltVar);
		//Converted into a Reference Type Double from Value type double
		System.out.println("The Boxed Object of Double type is :"+dblObj);
		
		int intVar = 100000;
		System.out.println("The Primitive Typed int is "+intVar);
		Integer intObj = new Integer(intVar);
		//Converted into a Reference Type Integer from value type int
		System.out.println("The Boxed Object of Integer Type is :"+intObj);
		System.out.println("-----------STRING TO PRIMITIVE USING WRAPPER--------");
		//WRAPPER CLASSES WILL HELP US IN CONVERTING STRING TO RESPECTIVE PRIMITIVE TYPES
		String strInt = "125626626";
		System.out.println("The int in String format :"+strInt);
		String strFlt = "123.456";
		System.out.println("The float in String format :"+strFlt);
		String strDbl = "2345566.678";
		System.out.println("The double in String format :"+strDbl);
		
		int intX;
		float fltX;
		double dblX;
		
		intX = Integer.parseInt(strInt);
		System.out.println("The Integer in String format converted to int :"+intX);
		
		fltX = Float.parseFloat(strFlt);
		System.out.println("The Float in String format converted to float :"+fltX);
		
		dblX = Double.parseDouble(strDbl);
		System.out.println("The Double in String format converted to double :"+dblX);
		
		System.out.println("---------------String Wrapped in Wrappers converted to STring ---------------");
		Double dbl1 = new Double("234454545.5678");
		Float flt1 = new Float("123.456");
		Integer int1 = new Integer(100000);
		
		String strDbl1 = dbl1.toString();
		System.out.println("The Double value converted to String :"+strDbl);
		
		String strFlt1 = flt1.toString();
		System.out.println("The Float value converted to String :"+strFlt1);
		
		String strInt1 = int1.toString();
		System.out.println("The Integer Value converted to String :"+strInt1);
		
		
		
		
		
		
		
		
		
		
		
	

		
		
		
		
		
		
		
		
		
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WrapperSampleClass wrapperObject = new WrapperSampleClass();
		wrapperObject.manipulateWrapperClasses();

	}

}
