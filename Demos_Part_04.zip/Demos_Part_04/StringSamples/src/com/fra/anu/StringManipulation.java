package com.fra.anu;

public class StringManipulation {

	public void manipulateString()
	{
		String str1 = "Chennai";
		str1 = "Mumbai";
		
		System.out.println("String str1 is "+str1);
		
		String str2 = "Bangalore";
		String str3 = "Bangalore";
		
		System.out.println(" str2.equals(str3)  :"+str2.equals(str3)); // TRUE
		System.out.println(" str2 == str3 "+(str2 == str3)); //
		
		String str4 = new String("hyderabad  is beautiful");
		String str5 = new String("Hyderabad is beautiful");
		
		System.out.println(" str4.equals(str5)  :"+str4.equals(str5)); // TRUE
		System.out.println(" str4 == str5 "+(str4 == str5)); //
		
		
		String str = "World is Beautiful";
		System.out.println("str.charAt(6)  :"+ str.charAt(6));
		System.out.println("str.codePointAt(6) :"+str.codePointAt(6));
		System.out.println("str.indexOf('B') :"+str.indexOf('B'));
		System.out.println("str.length() :"+str.length());
		System.out.println("str4.compareTo(str5) :"+str4.compareTo(str5));
		System.out.println("str4.substring(4) :"+str4.substring(4));
		System.out.println("str4.substring(6, 12) :"+str4.substring(6,12));
		
		String stra = "coimbatore";
		String strb = "Coimbatore";
		System.out.println(" stra.compareTo(strb) :"+stra.compareTo(strb));
		
		System.out.println("stra.compareToIgnoreCase(strb)" +stra.compareToIgnoreCase(strb));/**/
		
	} 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringManipulation sManip = new StringManipulation();
		sManip.manipulateString();

	}

}
