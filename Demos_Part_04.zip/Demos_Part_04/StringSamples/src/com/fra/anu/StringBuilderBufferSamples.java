package com.fra.anu;

import java.util.StringTokenizer;

public class StringBuilderBufferSamples {

	public void manipulateStringBuilderBuffers()
	{
		StringBuilder sbr = new StringBuilder("India is really Incredible");
		System.out.println("The Sbr before appending "+sbr);
		StringBuffer sbfr = new StringBuffer("India is really rich in resources");
		System.out.println("The sbfr before appending "+sbfr);
		sbr.append(" and also rich in culture");
		System.out.println("sbr after appending "+sbr);
		char[] mychar= {' ','a','n','d',' ','p','e','a','c','e','f','u','l'};
		sbfr.append(mychar);
		System.out.println("sbfr after appending "+sbfr);
		
		StringBuffer sbr1 = new StringBuffer("India is Peaceful");
		char[] strarr = {'c','o','l','o','u','r'};
		sbr1.append(strarr, 0, 6);
		System.out.println("The sbr after appended through insertion "+sbr1);
		
		StringBuffer sbur = new StringBuffer("India is Peaceful India is Peaceful");
		System.out.println("sbur Capacity is "+sbur.capacity());
		
		char[] mychars = {'c','u','l','t'};
		sbur.insert(17, mychars);
		System.out.println("The sbur after insertion in the middle "+sbur);
		
		StringTokenizer strToken = new StringTokenizer("this is simple tokenization"," ");
		//Iterator   hasNext()  next()
		//Enumeration
		while(strToken.hasMoreElements())//hasMoreElements //nextElement
		{
			System.out.println(strToken.nextElement());
		}
		String strz = new String("New Indian Continent");
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilderBufferSamples sbbs = new StringBuilderBufferSamples();
		sbbs.manipulateStringBuilderBuffers();
		
		

	}

}
