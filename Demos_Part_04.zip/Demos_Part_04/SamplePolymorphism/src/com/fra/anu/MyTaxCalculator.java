package com.fra.anu;
/*
class Shapes
{
	public void drawRandomShapes()
	{
		System.out.println("Displaying Random SHapes");
	}
	//CANNOT BE OVERRIDDEN
	public final void myFinalMethod()
	{
		System.out.println("Final Method in Non Final Class");
	}
}
//ABSTRACT CLASS CANNOT BE INSTANTIATED
abstract class TaxCalculator
{
	public  abstract void calculateStateTax();
	
	public void myMethod()
	{
		System.out.println("Displaying My Method");
	}
}
//FINAL CLASS PROHIBITS YOU FROM INHERITING
final class GovtTaxCalculator
{
	//FINAL METHOD PROHIBITS YOU FROM OVERRIDING
	public final void calculateGST()
	{
		System.out.println("GST Calculation is final...");
	}
}
/*
class TamilNaduTaxation extends GovTaxCalculator
{
	
}*/
public class MyTaxCalculator extends TaxCalculator {
	
	@Override
	public void calculateStateTax() {
		// TODO Auto-generated method stub
		System.out.println("My Karnataka Govt Tax Calculated");
	}
	
	public static void main(String args)
	{
		System.out.println("We are In Main..");
		MyTaxCalculator mtc = new MyTaxCalculator();
		mtc.calculateStateTax();
		mtc.myMethod();
		//INSTANTIATION OF THE ABSTRACT CLASS NOT ALLOWED
		//	TaxCalculator tc = new TaxCalculator();
		
		GovtTaxCalculator gtc = new GovtTaxCalculator();
		gtc.calculateGST();
		
		
	}

	
}
