package com.fra.anu;

public class CommandLineArgSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("The Cities are...");
		for(int i=0;i<args.length;i++)
		{
			System.out.println(args[i]);
		}
		for(String city : args)
		{
			System.out.println(city);
		}

	}

}
