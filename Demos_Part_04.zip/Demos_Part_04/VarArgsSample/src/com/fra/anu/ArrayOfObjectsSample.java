package com.fra.anu;
class Point
{
	int xCoord,yCoord;
	
	public Point()
	{
		xCoord = 0;
		yCoord = 0;
	}
	public Point(int xCoord,int yCoord)
	{
		this.xCoord = xCoord;
		this.yCoord = yCoord;
	}
	public void displayPoint()
	{
		System.out.println("X Coordinate is "+xCoord+" And Y Coordinate is "+yCoord);
	}
}
public class ArrayOfObjectsSample {

	public Point[] generateArray()
	{
		Point points[] = new Point[10];
		//Point[] points = new Point[10];
		/*
		points[0] = new Point(10,20)
		points[0] = new Point(10,20)
		
		points[9] = new Point(10,20)*/
		for(int i=0;i<10;i++)
		{
			points[i] = new Point(i+10,i+20);
		}
		
		return points;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayOfObjectsSample aos = new ArrayOfObjectsSample();
		Point[] myPoints = aos.generateArray();
		for(int i=0;i<10;i++)
		{
			myPoints[i].displayPoint();
		}
	}

}
