package com.fra.anu;

public class Calculator {

	public void calculateAverageScore(int score1,int score2,String... subjects)
	{
		double average = (score1 + score2 )/2;
		for(String subj : subjects)
		{
			System.out.println("The Subjects You have attempted are "+subj);
		}
		System.out.println("The Average is "+average);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calculator calci = new Calculator();
		calci.calculateAverageScore(78, 189, "SocialStudies","General Science","Mathematics");
		calci.calculateAverageScore(78, 189, "SocialStudies","General Science");
		calci.calculateAverageScore(78, 224, "SocialStudies","General Science","Mathematics","EV");

	}

}
