package com.fra.anu;

public class TitleCaseStringCreator {
	//life is beautiful
	public void convertToTitleCase(String... myString)
	{
		for(int i=0;i<myString.length;i++)
		{
			String str = myString[i]; // life -- l    ife
			char myChar = str.charAt(0);
			Character chars = new Character(myChar);
			String preStr,postStr;
			preStr = chars.toString(); // l
			preStr = preStr.toUpperCase(); //L
			postStr = str.substring(1); //iFe
			postStr = postStr.toLowerCase();//ife
			str = preStr +postStr;
			System.out.print(str+" ");
			
			
		}
		System.out.println();
		
	}
	
	public static void main(String[] args)
	{
		TitleCaseStringCreator tcsc = new TitleCaseStringCreator();
		tcsc.convertToTitleCase("life","is","beautiful");
		tcsc.convertToTitleCase("india","is","culturally","rich","country");
	}

}
