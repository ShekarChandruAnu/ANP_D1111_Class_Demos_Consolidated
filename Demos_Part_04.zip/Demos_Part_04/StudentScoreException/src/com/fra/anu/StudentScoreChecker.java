package com.fra.anu;

public class StudentScoreChecker {

	public StudentDetail getStudent(String studName,String studCourse,int... scores)
	{
		int subjectSize= scores.length;
		int myScores[] = new int[subjectSize];
		for(int i=0;i<subjectSize;i++)
		{
			myScores[i] = scores[i];
		}
		StudentDetail studentDetail = new StudentDetail(studName,studCourse,myScores);
		return studentDetail;
	}
	
	public void checkStudentScore(StudentDetail student) throws IneligibleStudentException
	{
		System.out.println("Checking Student Eligibility...");
		double average;
		int total = 0;
		for(int i=0;i<student.scores.length;i++)
		{
			total = total + student.scores[i];
		}
		average = total / student.scores.length;
		if(average < 75)
		{
			throw new IneligibleStudentException("Sorry Score Average not 75 Percent...");
		}
		System.out.println(" Excellent Your average is "+average);
		System.out.println("Student Eligible for the Scholarship...");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//StudentDetail student1 = new StudentDetail("Melwin","Course",{78,89,90,92,93}); 
		StudentScoreChecker schecker1 = new StudentScoreChecker();
		StudentDetail student1 = schecker1.getStudent("Melwin", "MCA", 78,79,90,92,93);
		student1.displayStudentDetails();
		try
		{
			schecker1.checkStudentScore(student1);
		}
		catch(IneligibleStudentException ise)
		{
			System.out.println(ise.message);
		}
		
		
		StudentDetail student2 = schecker1.getStudent("Sued Ali", "MCA", 88,89,70,82,93,92);
		student2.displayStudentDetails();
		try
		{
			schecker1.checkStudentScore(student2);
		}
		catch(IneligibleStudentException ise)
		{
			System.out.println(ise.message);
		}
		StudentDetail student3 = schecker1.getStudent("Ramesh", "BCA", 67,69,65,64);
		student3.displayStudentDetails();
		try
		{
			schecker1.checkStudentScore(student3);
		}
		catch(IneligibleStudentException ise)
		{
			System.out.println(ise.message);
		}
	}

}
