package com.fra.anu;

public class StudentDetail {
	
	String studentName;
	String course;
	int[] scores = new int[10];
	public StudentDetail() {
		super();
	}
	public StudentDetail(String studentName, String course, int[] scores) {
		super();
		this.studentName = studentName;
		this.course = course;
		this.scores = scores;
	}
	public void displayStudentDetails()
	{
		System.out.println("The Student Details are ");
		System.out.println("The Student Name :"+studentName);
		System.out.println("The Student Course :"+course);
		System.out.println("The Scores are ");
		for(int i=0;i<scores.length;i++)
		{
			System.out.print(scores[i]+" ");
		}
		
	}
	

}
