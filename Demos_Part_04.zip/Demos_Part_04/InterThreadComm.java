class Thread1
{
	int d;
	boolean flag=false;
	synchronized int getData()
	{
		if(flag==false)
		{
			try
			{
			wait();
			}
			catch(InterruptedException e)
			{
				System.out.println("Exception caught");
			}
		}
	System.out.println("Got Data:"+d);
	flag=false;
	notify();

	return d;
	}
	synchronized void putData(int d)
	{
		if(flag==true)
		{
			try
			{
				wait();
			}
			catch(InterruptedException e)
			{
			System.out.println("Exception caught");
			}
		}
		this.d=d;
		System.out.println("Put Data with value :"+d);
		flag=true;
		notify(); // wait and notify
	}
}
class producer implements Runnable
{
Thread1 t;
	public producer(Thread1 t)
	{
		this.t=t;
		new Thread(this,"Producer").start(); // Thread t1 = new Thread(this,"producer" - t1.start()
		System.out.println("Put called by Producer");
	}
	public void run()
	{
		int data=0;
		while(true)
		{
		data=data+1;
		t.putData(data);
		}
	}
}
class consumer implements Runnable
{
	Thread1 t;
	public consumer(Thread1 t)
	{
		this.t=t;
		new Thread(this,"Consumer").start();
		System.out.println("Get Called by Consumer");
	}
	public void run()
	{
		while(true)
		{
		t.getData();
		}
	}
}
public class InterThreadComm
{
	public static void main(String arg[])
	{
		Thread1 obj1=new Thread1();
		producer p=new producer(obj1);
		consumer c=new consumer(obj1);
	//p.start();
	//c.start();
		System.out.println("Press Ctrl+c to stop");
	}
}


