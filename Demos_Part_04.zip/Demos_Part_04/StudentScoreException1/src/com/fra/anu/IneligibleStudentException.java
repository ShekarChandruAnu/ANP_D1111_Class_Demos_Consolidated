package com.fra.anu;

public class IneligibleStudentException extends Exception {
	
	String message;
	public IneligibleStudentException(String message)
	{
		this.message = message;
	}

}
