package com.fra.anu;

public class Student {
	
	String studentName;
	String studentCourse;
	
	int[] scores = new int[10];
	public Student() {
		super();
	}
	public Student(String studentName, String studentCourse, int[] scores) {
		super();
		this.studentName = studentName;
		this.studentCourse = studentCourse;
		this.scores = scores;
	}
	
	public void displayStudentDetails()
	{
		System.out.println("The Student Details are ");
		System.out.println("Student Name "+studentName);
		System.out.println("Student Course "+studentCourse);
		System.out.println("The Scores are...");
		for(int i=0;i<scores.length;i++)
		{
			System.out.print(scores[i]+" ");
		}
	}
	

}
