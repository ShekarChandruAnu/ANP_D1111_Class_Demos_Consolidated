package com.fra.anu;

public class StudentScoreChecker {

	public Student getStudentWithScores(String studentName,String studentCourse,int... scores)
	{
		int sizeArr = scores.length;
		int scoreArr[] = new int[sizeArr];
		for(int i=0;i<sizeArr;i++)
		{
			scoreArr[i] = scores[i];
		}
		Student student = new Student(studentName,studentCourse,scoreArr);
		return student;
		
	}
	public void checkScore(Student student) throws IneligibleStudentException
	{
		System.out.println("Scrutinizing the Student Details...");
		int total =0;
		double average;
		for(int i=0;i<student.scores.length;i++)
		{
			total = total + student.scores[i];
		}
		average = total / student.scores.length;
		if(average < 75)
		{
			System.out.println("Sorry Your Average is "+average);
			throw new IneligibleStudentException("Sorry Ineligible for the Scholarships... since avg is less than 75");
		}
		System.out.println("Congrats !!! Eligible for the Scholarships and Your Average is "+average);
		System.out.println("Student score Scrutiny Completed");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentScoreChecker ssc = new StudentScoreChecker();
		Student student1 = ssc.getStudentWithScores("Harsha", "MBA", 78,79,89,80,92);
		Student student2 = ssc.getStudentWithScores("Kiran", "MCA", 68,69,79,60,52,58,57);
		Student student3 = ssc.getStudentWithScores("Manish", "BCA", 78,79,89);
		student1.displayStudentDetails();
		try
		{
			ssc.checkScore(student1);
		}
		catch(IneligibleStudentException ise)
		{
			System.out.println(ise.message);
		}
		student2.displayStudentDetails();
		try
		{
			ssc.checkScore(student2);
		}
		catch(IneligibleStudentException ise)
		{
			System.out.println(ise.message);
		}
		student3.displayStudentDetails();
		try
		{
			ssc.checkScore(student3);
		}
		catch(IneligibleStudentException ise)
		{
			System.out.println(ise.message);
		}
		

	}

}
