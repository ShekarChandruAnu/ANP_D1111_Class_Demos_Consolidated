package com.fra.anu;

public class StaticSample {

	//Created a NON STATIC VARIABLE
	int nonStaticVar; // 0
	//CREATED A STATIC VARIABLE
	static int staticVar; // 0
	
	//STATIC METHOD CAN ACCESS ONLY STATIC VARIABLE
	//NON STATIC METHOD CAN ACCESS BOTH STATIC AND NON STATIC VARIABLE
	//FIRST STATIC METHOD
	public static void staticMethod1()
	{
		staticVar++; // staticVar = staticVar+1
		System.out.println("The Value of Static Variable in STATIC METHOD 1 :"+staticVar);
		
	}
	//FIRST NON STATIC METHOD
	public void nonStaticMethod1()
	{
		staticVar++;
		nonStaticVar++;
		System.out.println("The Value of Static Variable in Non STATIC METHOD 1 :"+staticVar);
		System.out.println("The Value of Non Static Variable in NON STATIC METHOD 1 :"+nonStaticVar);
	}
	//SECOND STATIC METHOD
	public static void staticMethod2()
	{
		staticVar++; // staticVar = staticVar+1
		System.out.println("The Value of Static Variable in STATIC METHOD 2 :"+staticVar);
	}
	//SECOND NON STATIC METHOD
	public void nonStaticMethod2()
	{
		staticVar++;
		nonStaticVar++;
		System.out.println("The Value of Static Variable in Non STATIC METHOD 2 :"+staticVar);
		System.out.println("The Value of Non Static Variable in NON STATIC METHOD 2 :"+nonStaticVar);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StaticSample statSample1 = new StaticSample();
		StaticSample.staticMethod1(); //sv 1
		statSample1.nonStaticMethod1();//sv:2     nsv:1 //RESHMA
		statSample1.nonStaticMethod2();//sv:3      nsv:2 //MAY BE
		
		StaticSample statSample2 = new StaticSample();
		StaticSample.staticMethod2();  // sv:4    
		
		statSample2.nonStaticMethod1(); // sv : 5    nsv: 1 //
		statSample2.nonStaticMethod2(); // sv:  6     nsv: 2

	}

}
