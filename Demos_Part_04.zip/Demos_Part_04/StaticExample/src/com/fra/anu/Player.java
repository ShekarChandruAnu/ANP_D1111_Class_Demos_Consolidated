package com.fra.anu;
interface interface1
{
	
}
interface interface2
{
	
}
interface interface3 extends interface1,interface2
{
	
}
interface interface4
{
	
}
class ClassA
{
	
}
public class Player extends ClassA implements interface3,interface4{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
