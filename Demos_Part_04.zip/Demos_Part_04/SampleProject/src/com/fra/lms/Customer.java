package com.fra.lms;

public class Customer {

	String id;
	int score;
	Customer(String id,int score)
	{
		this.id = id;
		this.score = score;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer c = new Customer("S001",87);
		
	}

}
