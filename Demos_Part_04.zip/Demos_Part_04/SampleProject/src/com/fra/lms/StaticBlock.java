package com.fra.lms;
class Shapes
{
	public void display() {
		System.out.println("Displaying Random Shapes....");
	}
}
public class StaticBlock {

	static Shapes rectangle = new Shapes() {
		public void display()
		{
			System.out.println("Displaying Rectangles");
		}
	};
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		rectangle.display();
	}

}
