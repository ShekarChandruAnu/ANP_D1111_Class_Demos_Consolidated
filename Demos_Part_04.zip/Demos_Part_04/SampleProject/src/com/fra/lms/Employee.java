package com.fra.lms;
public class Employee {

	// ctrl++
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(" Hello welcome");
	}

}
