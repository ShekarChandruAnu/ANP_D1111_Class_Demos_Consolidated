package com.fra.anu;

public class ArrayIndexExceptionSample {

	int arr[] = new int[10];
	public void manipulateArray()
	{
		System.out.println("Entering the Array Manipulation Method");
		try
		{
			for(int i=0;i<=10;i++)
			{
				arr[i] = (i+1) * 100;
				System.out.println("Array Value is "+arr[i]);
			}
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			aie.printStackTrace();
		}
		System.out.println("Exiting the Array Manipulation Method");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("We are about to invoke Array Manipulation...");
		ArrayIndexExceptionSample ais = new ArrayIndexExceptionSample();
		
			ais.manipulateArray();
		
		System.out.println("We finished Array Manipulation Invocation");
		System.out.println("Exiting Main...");
	}

}
