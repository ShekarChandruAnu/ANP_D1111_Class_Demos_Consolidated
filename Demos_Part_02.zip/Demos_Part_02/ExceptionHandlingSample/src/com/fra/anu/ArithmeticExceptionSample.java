package com.fra.anu;

public class ArithmeticExceptionSample {

	double result;
	public void calculate(int num1,int num2)
	{
		System.out.println("Entering Calculate Method...");
		System.out.println("We are about to divide ...");
		try
		{
		result = num1 / num2;
		}
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
		}
		System.out.println("Num1 divided by Num2 is "+result);
		System.out.println("We finished Dividing...");
		System.out.println("Exiting Calculate Method");
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(" We are in Main Method");
		ArithmeticExceptionSample aes = new ArithmeticExceptionSample();
		
			aes.calculate(100, 20);
			aes.calculate(100, 25);
			aes.calculate(100, 0);
			aes.calculate(100, 50);
			aes.calculate(100, 4);
		
		
		System.out.println(" We are exiting Main Method");

	}

}
