package com.fra.anu;

public class InvalidAgeException extends Exception {

	String message;
	//Constructor to initialize message Data Member
	public InvalidAgeException (String message)
	{
		this.message = message;
	}
}
