package com.fra.anu;

public class RecruitmentProcess {

	public void checkAge(int age) throws InvalidAgeException
	{
		System.out.println("We are Into Age Scrutiny Method");
		System.out.println("We are about to check the Age Limit");
		if((age<20)||(age>30))
		{
			/*
			 * InvalidAgeException iae = new InvalidAgeException();
			 * throw iae;
			 */
			throw new InvalidAgeException("Sorry Valid Age is 20-30");
			
		}
		System.out.println("Age is Valid "+age+"Proceed for further recruitment Process");
		System.out.println("We have finished Age scrutinization");
		System.out.println("We will continue with the Remaining Part of the Recruitment Process");
	}
	public void callCheckAge(int age)
	{
		try
		{
			checkAge(age);
		}
		catch(InvalidAgeException iae)
		{
			System.out.println("Age Error Message :"+iae.message);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In The Process of Recruitment");
		RecruitmentProcess  rpc = new RecruitmentProcess();
	/*	try
		{*/
			rpc.callCheckAge(24); 
			rpc.callCheckAge(23);	
			rpc.callCheckAge(35);
			rpc.callCheckAge(22);
			rpc.callCheckAge(21);
		/*}
		catch(InvalidAgeException iae)
		{
			System.out.println("Age Error Message :"+iae.message);
		}*/
		System.out.println("We Finished Recruitment Age Scrutinization Process..");

	}

}
