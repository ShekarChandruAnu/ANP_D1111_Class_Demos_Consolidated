package com.fra.anu;

import java.util.Enumeration;
import java.util.Vector;

public class VectorSample {

	
	Vector <Employee> myVector = new Vector<Employee>(5,7);
	public void populateVector()
	{
		System.out.println("Initial Capacity "+myVector.capacity());
		myVector.addElement(new Employee("E001","Meera Kumar","Malleswaram","7873838393",1200,11.3f));
		myVector.addElement(new Employee("E002","Keerthana","Koramangala","7383834253",1300,10.3f));
		myVector.addElement(new Employee("E003","Kiran Kumari","Vijayanagar","5463838393",1700,13.3f));
		myVector.addElement(new Employee("E004","Kiran Kumar","RTNagar","7383838393",1000,12.3f));
		myVector.addElement(new Employee("E005","Kishan Kumar","Koramangala","7383865393",1200,11.3f));
		System.out.println("Initial Capacity after loading 5 elements "+myVector.capacity());
		myVector.addElement(new Employee("E006","Mohan Kumar","Jayanagar","7383838534",1500,14.3f));
		//myVector.add(index, element);
	}
	public void fetchVectorObjects()
	{
		Enumeration <Employee> vectorEnumer = myVector.elements();
		while(vectorEnumer.hasMoreElements())
		{
			Employee employee = vectorEnumer.nextElement();
			System.out.println(employee);
		}
		System.out.println("The Capacity of thr Vector is "+myVector.capacity());
		System.out.println("The Current Size of the Vector is "+myVector.size());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VectorSample vSample = new VectorSample();
		vSample.populateVector();
		vSample.fetchVectorObjects();

	}

}
