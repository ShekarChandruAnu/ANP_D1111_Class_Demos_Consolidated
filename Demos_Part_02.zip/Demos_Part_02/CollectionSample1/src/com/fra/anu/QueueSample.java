package com.fra.anu;

import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueSample {

	Queue <String> myQueue = new PriorityQueue<>();
	Queue <Employee> empQueue = new PriorityQueue<Employee>();
	
	public void populateQueue()
	{
		myQueue.add("Order 1");
		myQueue.add("Order 2");
		myQueue.add("Order 3");
		myQueue.add("Order 4");
		myQueue.add("Order 5");
		
	}

	public void fetchQThruIterator()
	{
		Iterator <String> qIter = myQueue.iterator();
		while(qIter.hasNext())
		{
			String qElement = qIter.next();
			System.out.println("The Order Proceseed "+qElement);
		}
	}
	public void populateEmpQueue()
	{
		empQueue.add(new Employee("E001","Meera Kumar","Malleswaram","7873838393",1200,11.3f));
		empQueue.add(new Employee("E002","Keerthana","Koramangala","7383834253",1300,10.3f));
		empQueue.add(new Employee("E003","Kiran Kumari","Vijayanagar","5463838393",1700,13.3f));
		empQueue.add(new Employee("E004","Kiran Kumar","RTNagar","7383838393",1000,12.3f));
		empQueue.add(new Employee("E005","Kishan Kumar","Koramangala","7383865393",1200,11.3f));
		empQueue.add(new Employee("E006","Mohan Kumar","Jayanagar","7383838534",1500,14.3f));
		
	}
	public void fetchEmpQueueThruIter()
	{
		Iterator <Employee> empQIter = empQueue.iterator();
		while(empQIter.hasNext())
		{
			Employee employee = empQIter.next();
			System.out.println("The Dequeued Element from Queue "+employee);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QueueSample qsamp = new QueueSample();
	/*	qsamp.populateQueue();
		qsamp.fetchQThruIterator(); // FIFO */
		qsamp.populateEmpQueue();
		qsamp.fetchEmpQueueThruIter();
	}

}
