package com.fra.anu;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class TreeMapEntrySetSample {
	// WELLS FARGO 
	TreeMap <String,Employee> employeeMap = new TreeMap<String,Employee>();
	
	public void populateTreeMap()
	{
		employeeMap.put("E004",new Employee("E004","Kiran Kumar","RTNagar","7383838393",1000,12.3f));
		employeeMap.put("E005",new Employee("E005","Kishan Kumar","Koramangala","7383865393",1200,11.3f));
		employeeMap.put("E006",new Employee("E006","Mohan Kumar","Jayanagar","7383838534",1500,14.3f));
		employeeMap.put("E003",new Employee("E003","Kiran Kumari","Vijayanagar","5463838393",1700,13.3f));
		employeeMap.put("E001",new Employee("E001","Meera Kumar","Malleswaram","7873838393",1200,11.3f));
		employeeMap.put("E002",new Employee("E002","Keerthana","Koramangala","7383834253",1300,10.3f));
		
	}
	public void fetchTreeMapUsingEntrySet()
	{
		Set <Entry <String,Employee>> myEntrySet = employeeMap.entrySet();
		Iterator  <Entry <String,Employee>>  myEntrySetIter = myEntrySet.iterator();
		while(myEntrySetIter.hasNext())
		{
			Entry <String,Employee> myEntry = myEntrySetIter.next();
			String myKey = myEntry.getKey();
			Employee myValue = myEntry.getValue();
			System.out.println("The Value for the Key "+myKey+" is "+myValue);
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMapEntrySetSample tmas = new TreeMapEntrySetSample();
		tmas.populateTreeMap();
		tmas.fetchTreeMapUsingEntrySet();

	}

}
