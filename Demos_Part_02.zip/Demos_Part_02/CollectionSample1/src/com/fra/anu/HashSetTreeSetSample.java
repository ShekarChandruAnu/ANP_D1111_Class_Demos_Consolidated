package com.fra.anu;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class HashSetTreeSetSample {

	HashSet <String> cityHashSet = new HashSet<String>();
	TreeSet <String> cityTreeSet = new TreeSet<String>();
	public void populateHashSet()
	{
		cityHashSet.add("Faridabad");
		cityHashSet.add("Ahmedabad");
		cityHashSet.add("Coimbatore");
		cityHashSet.add("Hyderabad");
		cityHashSet.add("Bangalore");
		cityHashSet.add("Ernakulam");
		cityHashSet.add("Hubli");
	}
	public void fetchHashSetObjects()
	{
				Iterator <String> myHashSetIter = cityHashSet.iterator();
				while(myHashSetIter.hasNext())
				{
					String myCity = myHashSetIter.next();
					System.out.println("City is "+myCity);
				}
		
	}
	public void populateTreeSet()
	{
		cityTreeSet.add("Faridabad");
		cityTreeSet.add("Ahmedabad");
		cityTreeSet.add("Coimbatore");
		cityTreeSet.add("Hyderabad");
		cityTreeSet.add("Bangalore");
		cityTreeSet.add("Ernakulam");
		cityTreeSet.add("Hubli");
	}
	public void fetchTreeSetObjects()
	{
		Iterator <String> myTreeSetIter = cityTreeSet.iterator();
		while(myTreeSetIter.hasNext())
		{
			String myCity = myTreeSetIter.next();
			System.out.println("City is "+myCity);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSetTreeSetSample hsts = new HashSetTreeSetSample();
		System.out.println("-------------Hash Set Objects-------------");
		hsts.populateHashSet();
		hsts.fetchHashSetObjects();
		System.out.println("-------------Tree Set Objects-------------");
		hsts.populateTreeSet();
		hsts.fetchTreeSetObjects();

	}

}
