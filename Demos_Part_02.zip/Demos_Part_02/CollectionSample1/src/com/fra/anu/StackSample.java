package com.fra.anu;

import java.util.Iterator;
import java.util.Stack;

public class StackSample {
	
	Stack <String> myStack = new Stack<String>();
	
	public void populateStack()
	{
		myStack.push("India");
		myStack.push("SriLanka");
		myStack.push("England");
		myStack.push("Norway");
		myStack.push("Australia");
		myStack.push("Germany");
	}
	public void populateStackThruAdd()
	{
		myStack.add("India");
		myStack.add("SriLanka");
		myStack.add("England");
		myStack.add("Norway");
		myStack.add("Australia");
		myStack.add("Germany");
	}
	public void fetchStackObjects()
	{
		System.out.println("The Size of The Stack before popping "+myStack.size());
		System.out.println("The Object peeked from Stack "+myStack.peek());
		System.out.println("The Size of The Stack after popping "+myStack.size());
		while(myStack.isEmpty() == false)
		{
			String country = myStack.pop();
			System.out.println("The Popped Country is "+country);
		}
		System.out.println("The Size of The Stack after popping all elements "+myStack.size());
	}
	public void checkPopnSize()
	{
		System.out.println("The Size of The Stack before popping "+myStack.size());
		System.out.println("The Popped Element is "+myStack.pop());
		System.out.println("The Size of The Stack after popping "+myStack.size());
	}
	public void fetchThruIterator()
	{
		Iterator <String> stackIter = myStack.iterator();
		while(stackIter.hasNext())
		{
			String country = stackIter.next();
			System.out.println("Country is "+country);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StackSample stack1 = new StackSample();
	/*	stack1.populateStack();
		stack1.fetchStackObjects();// POP FILO MAINTAINED
		System.out.println("--------calling fetch thru Iterator--------");
		stack1.populateStack();
		stack1.fetchThruIterator(); // FILO NOT MAINTAINED
		System.out.println("--------calling populate thru add--out thru pop------");
		stack1.populateStackThruAdd();
		stack1.fetchStackObjects();// pop FILO maintained
		System.out.println("--------calling populated after pop consumed-----");
		stack1.fetchStackObjects();// NOT DISPLAY BECAUSE ALL CONSUMED
		System.out.println("--------Populating thru add and Iterating-----");
		stack1.populateStackThruAdd();
		stack1.fetchThruIterator();// add vs Iterator so no FILO MAINTAINED
	*/
		stack1.populateStack();
		stack1.fetchStackObjects();// pop
		System.out.println("------");
		stack1.populateStack();
		stack1.checkPopnSize();
	}

}
