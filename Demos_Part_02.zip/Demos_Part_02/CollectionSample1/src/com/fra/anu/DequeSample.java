package com.fra.anu;

import java.util.ArrayDeque;
import java.util.Deque;

public class DequeSample {

	Deque <String> myDeque = new ArrayDeque<>();
	public void populateArrayDeque()
	{
		myDeque.add("Order 1");
		myDeque.add("Order 2");
		myDeque.add("Order 3");
		myDeque.add("Order 4");
		myDeque.add("Order 5");
	}
	public void fetchQueueElements()
	{
		System.out.println("The Deque Size before removing "+myDeque.size());
		while(myDeque.isEmpty() == false)
		{
			String myOrder = myDeque.remove(); 
			System.out.println("The Processed Order "+myOrder);
		}
		System.out.println("The Deque Size after removing all elements "+myDeque.size());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DequeSample dsamp = new DequeSample();
		dsamp.populateArrayDeque();
		dsamp.fetchQueueElements();

	}

}
