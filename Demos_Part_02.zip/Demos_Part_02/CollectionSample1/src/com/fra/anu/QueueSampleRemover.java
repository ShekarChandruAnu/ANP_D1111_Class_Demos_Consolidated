package com.fra.anu;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueSampleRemover {

	Queue <String>  ordersQueue = new PriorityQueue<>();
	public void populateQueue()
	{
		ordersQueue.add("Order 1");
		ordersQueue.add("Order 2");
		ordersQueue.add("Order 3");
		ordersQueue.add("Order 4");
		ordersQueue.add("Order 5");
	}
	public void fetchThruRemove()
	{
		System.out.println("The SIze of the Queue Before Removing "+ordersQueue.size());
		while(ordersQueue.isEmpty() == false)
		{
			String myOrder = ordersQueue.remove();
			System.out.println("The Order in Queue "+myOrder);
		}
		System.out.println("The SIze of the Queue After Removing "+ordersQueue.size());
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub()
		QueueSampleRemover qsr = new QueueSampleRemover();
		qsr.populateQueue();
		qsr.fetchThruRemove();

	}

}
