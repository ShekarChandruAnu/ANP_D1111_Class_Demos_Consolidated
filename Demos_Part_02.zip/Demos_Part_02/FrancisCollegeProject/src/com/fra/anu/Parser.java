package com.fra.anu;

public abstract class Parser {
	
	public abstract void parse(String fileName);

}
