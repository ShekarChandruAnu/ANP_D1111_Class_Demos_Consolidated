package com.fra.anu;

//XmlParser class inherits Asbtract class Parser
public class XmlParser extends Parser {

	@Override
	public void parse(String fileName) {
		// TODO Auto-generated method stub
		System.out.println("Parsing "+fileName+" XML File ");
	}

}
