package com.fra.anu;

public class Student {
	//(080)-(9393939)
	/*
	 * studentId,studentName,studentAddress,studentPhone,score[]
	 */
	String studentId;
	String studentName;
	String studentAddress;
	String studentPhone;
	int[] score = new int[5];
	// DEFAULT CONSTRUCTOR
	public Student()
	{
		score = new int[5];
		this.studentId = "S001";
		this.studentName = "Harsha";
		this.studentAddress = "RTNagar";
		this.studentPhone="9839399393";
		this.score[0] = 86;
		this.score[1] = 87;
		this.score[2] = 89;
		this.score[3] = 92;
		this.score[4] = 84;
	}
	//OVERLOADED CONSTRUCTOR - ALL-ARGS CONSTRUCTOR
	public Student(String studentId,String studentName,String studentAddress,String studentPhone,int[] score)
	{
		
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentAddress = studentAddress;
		this.studentPhone = studentPhone;
		this.score = score;
	}
	//OVERLOADED CONSTRUCTOR with 3 Parameters
		public Student(String studentId,String studentName,String studentAddress)
		{
			this.studentId = studentId;
			this.studentName = studentName;
			this.studentAddress = studentAddress;
			
		}
	public void displayStudentDetails()
	{
		System.out.println("Student Details are....");
		System.out.println("Student Id "+studentId);
		System.out.println("Student Name "+studentName);
		System.out.println("Student Address "+studentAddress);
		System.out.println("Student Phone "+studentPhone);
		for(int i=0;i<5;i++)
		{
			System.out.println("Score of Subject "+(i+1)+" Is :"+score[i]);
		}
	}
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student melvin = new Student();
		melvin.displayStudentDetails();
		System.out.println("-------");
		int[] scores = {82,87,83,89,92};
		Student suwedAli = new Student("S002","SuwedAli","RTNagar","9839393933",scores);
		suwedAli.displayStudentDetails();
		System.out.println("------");
		Student vinith = new Student("S003","Vinith","Malleswaram");
		vinith.displayStudentDetails();
	}

}
