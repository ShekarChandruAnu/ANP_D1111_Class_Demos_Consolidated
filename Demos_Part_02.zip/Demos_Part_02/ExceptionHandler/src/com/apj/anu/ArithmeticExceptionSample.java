package com.apj.anu;

public class ArithmeticExceptionSample {

	public void calculate(int a,int b)
	{
		int result=0;
		System.out.println("--We are In Calculate Method.....");
		try
		{
			result = a / b;
		}
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
		}
		System.out.println("The Result is "+result);
		System.out.println("--We are Exiting Calculate Method.....");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArithmeticExceptionSample aes = new ArithmeticExceptionSample();
		System.out.println("About to Invoke Calculator Method....");
		
			aes.calculate(100, 20);
		
			aes.calculate(100, 50);
			aes.calculate(100, 0);
			aes.calculate(100, 25);
			aes.calculate(100, 10);
		
		System.out.println("Finished Execution of Calculator Method...");

	}

}
