package com.apj.anu;

public class ArrayIndexExceptionSample {

	public void manipulateArray()
	{
		int score[] = new int[10];
		System.out.println("We are in Array Manipulation method");
		try
		{
			for(int i=0;i<=10;i++)
			{
			score[i] = (i+1)*10;
			System.out.println("Array Element is "+score[i]);
			}
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			aie.printStackTrace();
		}
		System.out.println("Array Manipulation Completed...");
		System.out.println("Exiting Array Manipulation Method...");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayIndexExceptionSample aies = new ArrayIndexExceptionSample();
		System.out.println(" Array Manipulation Method Being invoked");
	
		
				aies.manipulateArray();
			
		
		System.out.println("Array Manipulation Invocation Completed...");

	}

}
