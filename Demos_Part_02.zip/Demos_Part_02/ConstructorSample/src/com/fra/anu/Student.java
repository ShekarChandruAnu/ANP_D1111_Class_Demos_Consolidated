package com.fra.anu;

public class Student {

	String studentId;
	String studentName;
	String studentAddress;
	String studentPhone;
	int[] scores = new int[5];
	//DEFAULT CONSTRUCTOR - PARAMETERLESS CONSTR
	public Student()
	{
		this.studentId = "S001";
		this.studentName = "Harsha";
		this.studentAddress = "RTNagar";
		this.studentPhone = "9829292992";
		this.scores[0] = 87;
		this.scores[1] = 82;
		this.scores[2] = 81;
		this.scores[3] = 80;
		this.scores[4] = 89;
	}
	//OVERLOADED CONSTR - ALL ARGS CONSTR
	public Student(String studentId,String studentName,String studentAddress,String studentPhone,int[] scores)
	{
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentAddress = studentAddress;
		this.studentPhone = studentPhone;
		this.scores = scores;
	}
	//OVERLOADED CONSTR WITH 3 PARAMS
	public Student(String studentId,String studentName,String studentAddress)
	{
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentAddress = studentAddress;
	}
	public void displayStudent()
	{
		System.out.println("The Student Details are...");
		System.out.println("Student Id "+studentId);
		System.out.println("Student Name "+studentName);
		System.out.println("Student Address "+studentAddress);
		System.out.println("Student Phone "+studentPhone);
		for (int i=0;i<5;i++)
		{
			System.out.println("Score of subject "+(i+1)+" is "+scores[i]);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student student1 = new Student();
		student1.displayStudent();
		System.out.println("-------");
		int hisscores[] = {82,83,85,86,89};
		Student student2 = new Student("S002","Kiran","Malleswaram","9838383838",hisscores);
		student2.displayStudent();
		System.out.println("-------");
		
		Student student3 = new Student("S003","Mayur","Koramangala");
		student3.displayStudent();

	}

}
