package com.fra.anu;

public class Customer {
	
	private String customerId ;
	private String customerName;
	private String customerPhone;
	private int purchaseValue;
	
	public String getCustomerId()
	{
		return this.customerId;
	}
	public void setCustomerId(String customerId)
	{
		this.customerId = customerId;
	}
	
	public String getCustomerName()
	{
		return this.customerName;
	}
	public void setCustomerName(String customerName)
	{
		this.customerName = customerName;
	}
	
	public String getCustomerPhone()
	{
		return this.customerPhone;
	}
	public void setCustomerPhone(String customerPhone)
	{
		this.customerPhone = customerPhone;
	}
	//READING
	public int getPurchaseValue()
	{
		return this.purchaseValue;
		
	}
	//WRITING
	public void setPurchaseValue(int purchaseValue)
	{
		this.purchaseValue=purchaseValue;
	}
	
	public void displayCustomerDetails()
	{
		System.out.println("Customer Details are...");
		System.out.println("Customer Id "+customerId);
		System.out.println("Customer Name "+customerName);
		System.out.println("Customer Phone "+customerPhone);
		System.out.println("Purchase Value "+purchaseValue);
	}
 /**/	public String toString()
	{
		String custStr = "Customer "+customerName+"With an Id "+customerId
				+"With a Contact No "+customerPhone
				+" Purchase Goods worth"+purchaseValue;
		return custStr;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customer1 = new Customer();
		customer1.setCustomerId("C001");
		customer1.setCustomerName("Harsha");
		customer1.setCustomerPhone("98494949944");
		customer1.setPurchaseValue(10000);
		
		customer1.displayCustomerDetails();
		
		System.out.println("The Customer Id "+customer1.getCustomerId());
		System.out.println("The Customer Name "+customer1.getCustomerName());
		System.out.println("The Customer Phone "+customer1.getCustomerPhone());
		System.out.println("The Purchase Value "+customer1.getPurchaseValue());
		System.out.println("--------");
		System.out.println("The Customer Details are "+customer1);
		
		

	}

}
