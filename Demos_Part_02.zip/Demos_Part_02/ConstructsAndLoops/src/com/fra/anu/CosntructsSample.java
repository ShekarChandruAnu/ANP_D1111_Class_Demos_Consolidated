package com.fra.anu;

public class CosntructsSample {

	public void checkScore(int score)
	{
		if(score >= 50)
		{
			System.out.println("Good Passed");
		}
		else
		{
			System.out.println("Sorry Try AGain...");
		}
	}
	public void checkScoreWithGrade(int score)
	{
		if(score >= 0 && score <= 100)
		{
			if(score >= 50 && score < 60)
			{
				System.out.println("Good Passed...");
			}
			else if(score >= 60 && score < 70)
			{
				System.out.println("Very Good Secured First Class..");
			}
			else if(score >= 70 && score <= 100)
			{
				System.out.println("Excellent, Secured Distinction..");
			}
			else
			{
				System.out.println("Sorry Try Gain");
			}
		}
		else
		{
				System.out.println("Sorry Range Should be between 0 - 100");
		}
		
			
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CosntructsSample csamp = new CosntructsSample();
		csamp.checkScore(45);
		csamp.checkScore(67);
		System.out.println("--------IF ELSE IF-----");
		csamp.checkScoreWithGrade(45);
		csamp.checkScoreWithGrade(55);
		csamp.checkScoreWithGrade(65);
		csamp.checkScoreWithGrade(175);
		csamp.checkScoreWithGrade(-175);
		

	}

}
