package com.fra.anu;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListGenericSample {

	//CTrl+shift+o
	ArrayList <Employee> employees = new ArrayList<Employee>();
	
	public void populateArrayList()
	{
		Employee employee1 = new Employee("E001","Harsha","RTNagar","9393993939",1000,12.34f);
		employees.add(employee1);
		employees.add(new Employee("E002","Kiran ","Indiranagar","9384593993",3000,13.45f));
		employees.add(new Employee("E003","Suman ","KRPuram","9383993433",4000,11.45f));
		employees.add(new Employee("E004","Meera ","Malleswaram","9383563993",3000,10.45f));
		employees.add(new Employee("E005","Suma ","Indiranagar","9383997893",2500,12.45f));
		
		employees.add(2, new Employee("E002a","Kishan ","Koramangala","9674593993",3500,12.45f));
		
	}
	public void fetchArrayListObjects()
	{
		Iterator <Employee> empIter = employees.iterator();
		System.out.println("The Employee Objects are...");
		while(empIter.hasNext())
		{
			Employee myEmployee = empIter.next();
			System.out.println(myEmployee);
		}
		
		Employee employeeat2 =employees.get(2);
		System.out.println("Employee at 2 is "+employeeat2);
		employees.remove(3);
		System.out.println("---------after removal at 3 ");
		System.out.println("Employee Objects after removing at 3 index");
		for(Employee e : employees)
		{
			System.out.println(e);
		}
	}
	// ArrayList <Employee> employees = new ArrayList<>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayListGenericSample algs = new ArrayListGenericSample();
		algs.populateArrayList();
		algs.fetchArrayListObjects();

	}

}
