package com.fra.anu;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListSample {

	//GENERICS
	ArrayList customers = new ArrayList();
	//ArrayList <Customer> customers1 = new ArrayList<Customer>();
	public void populateArrayList()
	{
		customers.add("Hello World");
		customers.add("New World");
		customers.add(20000); // BOXING - VALUE TYPE TO REFERENCE 
		customers.add(234.567); 
		customers.add(true);
		
	}
	public void fetchArrayListContents()
	{
		Iterator custIter = customers.iterator();
		while(custIter.hasNext())
		{
			Object object = custIter.next(); //typeOf
			System.out.println("The Object in ArrayList is "+object);
		}
	}
	public void fetchArrayListUsingFastEnumer()
	{
		System.out.println(" Objects int he Customers List are ..");
		for(Object object : customers )
		{
			System.out.println(object);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayListSample als = new ArrayListSample();
		als.populateArrayList();
		als.fetchArrayListContents();
		als.fetchArrayListUsingFastEnumer();

	}

}
