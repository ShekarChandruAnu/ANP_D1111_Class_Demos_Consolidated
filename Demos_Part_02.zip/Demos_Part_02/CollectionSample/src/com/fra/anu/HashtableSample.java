package com.fra.anu;

import java.util.Enumeration;
import java.util.Hashtable;

public class HashtableSample {

	Hashtable <String,Integer> empScores = new Hashtable<String,Integer>();
	
	public void populateHashTable()
	{
		empScores.put("E001",89);
		empScores.put("E002",79);
		empScores.put("E003",69);
		empScores.put("E004",59);
		empScores.put("E005",92);
		
	}
	public void fetchHashtableData()
	{
		Enumeration <String> myKeys = empScores.keys();
		while(myKeys.hasMoreElements())
		{
			String myKey = myKeys.nextElement();
			Integer myScore = empScores.get(myKey);
			System.out.println("The Score for the Key "+myKey+" Is "+myScore);
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashtableSample hts = new HashtableSample();
		hts.populateHashTable();
		hts.fetchHashtableData();

	}

}
