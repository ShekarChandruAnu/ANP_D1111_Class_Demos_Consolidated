package com.fra.anu;

import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

public class HashTableSample2 {

	// Key : String Value : Employee
	Hashtable <String,Employee> empHashTable = new Hashtable<String,Employee>();
	public void populateHashTable()
	{
		empHashTable.put("E001", new Employee("E001","Kiran Kumar","RTNagar","9839956393",10000,12.34f));
		empHashTable.put("E002", new Employee("E002","Suman Kumar","Malleswaram","9839943393",12000,13.34f));
		empHashTable.put("E003", new Employee("E003","Mahesh Kumar","Koramangala","9823939393",14000,11.34f));
		empHashTable.put("E004", new Employee("E004","Kiran Kumari","Indiranagar","9839456393",15000,10.34f));
		empHashTable.put("E005", new Employee("E005","SumanShri","WilsonGarden","9839978993",16000,11.34f));
		empHashTable.put("E006", new Employee("E006","Keerthana","RTNagar","9839939393",17000,14.34f));
		empHashTable.put("E006", new Employee("E006a","KeerthanaMohan","Koramangala","9829939393",16800,16.34f));
		
	} //
	public void fetchHashTableUsingValues()
	{
		Collection myHtableCol = empHashTable.values();
	/*	Iterator htIter = myHtableCol.iterator();
		while(htIter.hasNext())
		{
			Employee employee = (Employee)htIter.next();
		}*/
		Iterator <Employee> htIter = myHtableCol.iterator();
		System.out.println("The Values of Employee type in the Hash Table are...");
		while(htIter.hasNext())
		{
			Employee employee = htIter.next();
			System.out.println(employee);
		}
	}
	public void fetchHashTableUsingKeySet()
	{
		Set <String> myKeySet = empHashTable.keySet();
		Iterator <String> myKeyIter = myKeySet.iterator();
		while(myKeyIter.hasNext())
		{
			String myKey = myKeyIter.next();
			System.out.println("The Value for the Key "+myKey+" is :"+empHashTable.get(myKey));
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashTableSample2 hst2 = new HashTableSample2();
		System.out.println("----------Traversing HashTable through Values----------");
		hst2.populateHashTable();
		hst2.fetchHashTableUsingValues();
		System.out.println("----------Traversing HashTable through KeySet ----------");
		hst2.fetchHashTableUsingKeySet();

	}

}
