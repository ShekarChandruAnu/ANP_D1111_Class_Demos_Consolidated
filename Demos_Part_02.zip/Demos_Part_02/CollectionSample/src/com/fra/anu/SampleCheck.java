package com.fra.anu;

public class SampleCheck {

	public void add(int a,int b,int c)
	{
		
	}
	public void add(int a,float b,int c)
	{
		
	}
	public void add(int a,int b,float c)
	{
		
	}
	public void add(double a,double b)
	{
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
