package com.fra.anu;

public class Student {

	String studId;
	String studName;
	String studAddress;
	int score;
	
	public Student() {
		super();
	}

	public Student(String studId, String studName, String studAddress, int score) {
		super();
		this.studId = studId;
		this.studName = studName;
		this.studAddress = studAddress;
		this.score = score;
	}

	public String getStudId() {
		return studId;
	}

	public void setStudId(String studId) {
		this.studId = studId;
	}

	public String getStudName() {
		return studName;
	}

	public void setStudName(String studName) {
		this.studName = studName;
	}

	public String getStudAddress() {
		return studAddress;
	}

	public void setStudAddress(String studAddress) {
		this.studAddress = studAddress;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", studAddress=" + studAddress + ", score="
				+ score + "]";
	}
	
	
}
