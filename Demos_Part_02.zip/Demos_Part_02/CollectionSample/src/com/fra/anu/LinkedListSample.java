package com.fra.anu;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListSample {

	LinkedList <Student> students = new LinkedList<Student>();
	
	public void populateLinkedList()
	{
		//students.add(new Student("S001","Kiran","RTNagar",89));
		students.add(new Student("S002","Kiran","RTNagar",89));
		students.add(new Student("S003","Kiran","Malleswaram",79));
		students.add(new Student("S004","Kiran","Koramangala",69));
		students.add(new Student("S005","Kiran","RKPuram",89));
		students.add(new Student("S006","Kiran","Shanthinagar",92));
		students.addFirst(new Student("S001","Kiran","RTNagar",89));
		students.addLast(new Student("S007","Soman","Indiranagar",87)); /*	 */
	}
	public void fetchLinkedListDataThruIterator()
	{
		//Iterator studIter = students.iterator();
		Iterator <Student> studIter = students.iterator();
		System.out.println("Student Objects are....");
		while(studIter.hasNext())
		{
			//Student student = (Student) studIter.next();
			Student student = studIter.next();
			System.out.println(student);
		}
	}
	
	public void fetchLinkedListInDescendingOrder()
	{
		Iterator <Student> studDescIter = students.descendingIterator();
		System.out.println("Student Objects in Descending Order are....");
		while(studDescIter.hasNext())
		{
			//Student student = (Student) studIter.next();
			Student studentDesc = studDescIter.next();
			System.out.println(studentDesc);
		}
	}
	public void fetchLinkedListThruFastEnumeration()
	{
		for(Student student : students)
		{
			System.out.println(student);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedListSample lls = new LinkedListSample();
		lls.populateLinkedList();
		lls.fetchLinkedListDataThruIterator();
		System.out.println("---------Descending Order----");
		lls.fetchLinkedListInDescendingOrder();
		System.out.println("------------Fetch Objects using Fast Enumeration----------------");
		lls.fetchLinkedListThruFastEnumeration();
	}

}
