package com.fra.anu;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

public class HashMapTreeMapSample {

	
	HashMap <String,Integer> myHashMap = new HashMap<String,Integer>();
	TreeMap <String,Integer> myTreeMap = new TreeMap<String,Integer>();
	
	public void populateHashMap()
	{
		myHashMap.put("E007", 90);
		myHashMap.put("E003", 80);
		myHashMap.put("E006", 70);
		myHashMap.put("E004", 68);
		myHashMap.put("E005", 58);
		myHashMap.put("E002", 72);
		myHashMap.put("E001", 83);
		
	}
	public void populateTreeMap()
	{
		myTreeMap.put("E007", 90);
		myTreeMap.put("E003", 80);
		myTreeMap.put("E006", 70);
		myTreeMap.put("E004", 68);
		myTreeMap.put("E005", 58);
		myTreeMap.put("E002", 72);
		myTreeMap.put("E001", 83);
	}
	public void fetchHashMapObjects()
	{
		Set <String> myKeySet = myHashMap.keySet();
		Iterator <String> myKeyIter = myKeySet.iterator();
		while(myKeyIter.hasNext())
		{
			String myKey = myKeyIter.next();
			System.out.println("The Value for the Key "+myKey+" is "+myHashMap.get(myKey));
		}
	}
	public void fetchTreeMapObjects()
	{
		Set <String> myKeySet = myTreeMap.keySet();
		Iterator <String> myKeyIter = myKeySet.iterator();
		while(myKeyIter.hasNext())
		{
			String myKey = myKeyIter.next();
			System.out.println("The Value for the Key "+myKey+" is "+myTreeMap.get(myKey));
		}
		
	}
	
	public void fetchHashMapTreeMapValues()
	{
		Collection myHMapValues = myHashMap.values();
		Collection myTMapValues = myTreeMap.values();
		Iterator <Integer> hMapIter = myHMapValues.iterator();
		Iterator <Integer> tMapIter = myTMapValues.iterator();
		System.out.println("Values Iterated over HashMap....");
		while(hMapIter.hasNext())
		{
			Integer myHMapValue = hMapIter.next();
			System.out.println(myHMapValue);
		}
		System.out.println("Values Iterated over TreeMap....");
		while(tMapIter.hasNext())
		{
			Integer myTMapValue = tMapIter.next();
			System.out.println(myTMapValue);
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashMapTreeMapSample htms = new HashMapTreeMapSample();
		System.out.println("--------Dealing with HashMap-------");
		htms.populateHashMap();
		htms.fetchHashMapObjects();
		
		System.out.println("--------Dealing with TreeMap-------");
		htms.populateTreeMap();
		htms.fetchTreeMapObjects();
		
		System.out.println("-----------Using values Method of HashMap & TreeMap------------");
		htms.fetchHashMapTreeMapValues();
	}

}
