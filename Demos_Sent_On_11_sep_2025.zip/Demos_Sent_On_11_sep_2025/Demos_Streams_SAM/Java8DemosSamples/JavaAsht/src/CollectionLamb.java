import java.util.ArrayList;
import java.util.Collections;

class Product
{
	String pId;
	int price;
	public Product() {
		super();
	}
	public Product(String pId, int price) {
		super();
		this.pId = pId;
		this.price = price;
	}
	public String getpId() {
		return pId;
	}
	public void setpId(String pId) {
		this.pId = pId;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [pId=" + pId + ", price=" + price + "]";
	}
	
	
	
}
public class CollectionLamb {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		
		ArrayList <Product> products = new ArrayList<Product>();
		products.add(new Product("P003",1000));
		products.add(new Product("P002",1500));
		products.add(new Product("P001",2000));
		
		Collections.sort(products,(p1,p2) -> {return p1.pId.compareTo(p2.pId);});
		for(Product p:products)
		{
			System.out.println(p);
		}
	}

}
