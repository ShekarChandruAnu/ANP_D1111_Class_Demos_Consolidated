import java.util.ArrayList;
import java.util.Collections;

class Product
{
	String productId;
	String productName;
	int price;
	
	
	public Product() {
		super();
		
	}


	public Product(String productId, String productName, int price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
	}


	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", price=" + price + "]";
	}
	
}
public class LambdaExpression1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList <Product> products = new ArrayList<Product>();
		
		products.add(new Product("P003","Refrigerator",34000));
		products.add(new Product("P005","Television",20000));
		products.add(new Product("P001","Grinder",10000));
		products.add(new Product("P002","Mixer",8000));
		products.add(new Product("P004","AudioPlayer",18000));
		/*
		class NameSorter implements Comparator <Product>
		{
		public int compare(Product p1,Product p2)
		{
		return p1.prodName.compareTo(p2.productName);
		}
		} */
		//Collections.sort(products,new NameSorter());
		Collections.sort(products, (p1,p2) -> { return p1.productName.compareTo(p2.productName); });
		
		for(Product p : products)
		{
			System.out.println(p);
		}
		System.out.println("------------------------");
		Collections.sort(products, (p1,p2) -> { return p1.productId.compareTo(p2.productId); });
		for(Product p : products)
		{
			System.out.println(p);
		}
		System.out.println("------------------------");
		Collections.sort(products, (p1,p2) -> { return p1.productId.compareTo(p2.productId); });
		for(Product p : products)
		{
			System.out.println(p);
		}
		System.out.println("------------------------");

	}

}
