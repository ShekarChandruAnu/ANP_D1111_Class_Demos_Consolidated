import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Stream;

class ProductX
{
	String productId;
	String productName;
	int price;
	
	
	public ProductX() {
		super();
		
	}


	public ProductX(String productId, String productName, int price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.price = price;
	}


	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", price=" + price + "]";
	}
	
}
public class LambdaExpression2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

ArrayList <ProductX> products = new ArrayList<ProductX>();
		
		products.add(new ProductX("P003","Refrigerator",34000));
		products.add(new ProductX("P005","Television",20000));
		products.add(new ProductX("P001","Grinder",10000));
		products.add(new ProductX("P002","Mixer",8000));
		products.add(new ProductX("P004","AudioPlayer",18000));
		
		Stream <ProductX> filterProducts = products.stream().filter(p -> p.price >= 15000);
		
		filterProducts.forEach(
				p ->{System.out.println("Product Id "+p.productId+" Product Name :"+p.productName+" Price "+p.price);}
				);
		System.out.println("---------------------");
		Stream <ProductX> filterProducts1 = products.stream().filter(p -> p.price <= 18000);
		
		filterProducts1.forEach(
				p ->{System.out.println("Product Id "+p.productId+" Product Name :"+p.productName+" Price "+p.price);}
				);
	}

}
