import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Stream <Integer> myStream = Stream.of(10,20,30,40,50,60,70,80,90,100);
		
		List <Integer> myList = myStream.collect(Collectors.toList());
		
		System.out.println(myList);
		
		Stream <Integer> myStream1 = Stream.of(new Integer[] {100,200,300,400,500,600,700,800});
		
		List <Integer> myList1 = myStream1.collect(Collectors.toList());
		
		System.out.println(myList1);
		
		ArrayList <Integer> list1 = new ArrayList<Integer>();
		
		for(int i=0;i<100;i++)
		{
			list1.add(i);
		}
		
		Stream myIntParStream = list1.parallelStream();
		List <Integer> myIntList1 = (List<Integer>) myIntParStream.collect(Collectors.toList());
		
		System.out.println(myIntList1);
		
		Stream myIntSeqStream = list1.stream();
		List <Integer> myIntList2 = (List<Integer>) myIntSeqStream.collect(Collectors.toList());
		System.out.println(myIntList2);
		System.out.println("-------------------Products Accessed thru Streams-------------------");
		ArrayList <Product> products = new ArrayList<Product>();
		products.add(new Product("P001","Television",10000,67));
		products.add(new Product("P002","Refrigerator",18000,120));
		products.add(new Product("P003","AirConditioner",25000,75));
		products.add(new Product("P004","WashingMachine",19000,80));
		products.add(new Product("P005","DishWasher",25000,45));
		products.add(new Product("P006","StereoPlayer",8000,124));
		
		Stream <Product> myProductStream = products.stream().filter(p -> p.prodPrice >= 18000 );
		
		myProductStream.forEach(product -> System.out.println("Product Id :" +product.productId+" Product Name "+product.productName+" Product Price "+product.prodPrice));
		
	}

}
