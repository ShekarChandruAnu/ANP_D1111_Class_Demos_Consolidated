import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamSample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Stream <Integer> myStream = Stream.of(90,100,70,50,60,80,75,95,62,98,81);
		
		Integer nums[] = {800,200,700,400,500};
			
			// Transferring from Stream to List
			List <Integer> myList = myStream.collect(Collectors.toList());
			System.out.println(myList);
			
			// Transferring from List to Stream
			Stream <Integer> myStream1 = myList.stream();
			
			//Transferring back to List
			List <Integer> myList1 = myStream1.collect(Collectors.toList());
			
			System.out.println(myList1);
			
						//Stream <Integer> myStream2 = myList1.parallelStream();
			Stream <Integer> myStream2 = myList1.stream();
						Stream <Integer> sortedStream =	myStream2.sorted();
						sortedStream.forEach(System.out::println);
						
						/*Stream <Integer> myStr2 = myStream2.sorted();
						System.out.println(myStr2);*/
						
						Stream <Integer> myStream3 = myList1.parallelStream();
						List <Integer> myList2 = myStream3.collect(Collectors.toList());
						
						
								
						System.out.println("---------------------Sorted List---------------------");
					//	System.out.println(myStr2);
						myList2.stream()                           // Created a stream from the list
		                .filter(num -> num > 10)        //filter operation to get only numbers greater than 10
		                .forEach(System.out::println);  //
			
						List <String> myList3 =new ArrayList<String>();
						myList3.add("Dave");
						myList3.add("Raj");
						myList3.add("Kiran");
						myList3.add("Suman");
						myList3.add("Amar");
						myList3.add("Emanuel");
						
						System.out.println("---------------List in UpperCase-------------");
						myList3.stream()
		                .map(name -> name.toUpperCase()) //map() takes an input of Function<T, R> type.
		                .forEach(System.out::println);
						
						Stream<Integer> stream11 = Stream.of(1,2,3,4,5,6,7,8,9);
				        stream11.forEach(p -> System.out.println(p));
	}

}
