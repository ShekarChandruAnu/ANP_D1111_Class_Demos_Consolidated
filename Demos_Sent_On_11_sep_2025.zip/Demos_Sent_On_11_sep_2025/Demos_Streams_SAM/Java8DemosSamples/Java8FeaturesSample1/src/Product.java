
public class Product {

		String productId;
		String productName;
		int prodPrice;
		int qtyOnHand;
		
		public Product() {
			super();
		}
		// Add Default Constructor
		// Add Overloaded Constructor
		// Add Getters/Setters
		// Add toString()
		public Product(String productId, String productName, int prodPrice, int qtyOnHand) {
			super();
			this.productId = productId;
			this.productName = productName;
			this.prodPrice = prodPrice;
			this.qtyOnHand = qtyOnHand;
		}

		public String getProductId() {
			return productId;
		}

		public void setProductId(String productId) {
			this.productId = productId;
		}

		public String getProductName() {
			return productName;
		}

		public void setProductName(String productName) {
			this.productName = productName;
		}

		public int getProdPrice() {
			return prodPrice;
		}

		public void setProdPrice(int prodPrice) {
			this.prodPrice = prodPrice;
		}

		public int getQtyOnHand() {
			return qtyOnHand;
		}

		public void setQtyOnHand(int qtyOnHand) {
			this.qtyOnHand = qtyOnHand;
		}

		@Override
		public String toString() {
			return "Product [productId=" + productId + ", productName=" + productName + ", prodPrice=" + prodPrice
					+ ", qtyOnHand=" + qtyOnHand + "]";
		}
		
		
		
}
