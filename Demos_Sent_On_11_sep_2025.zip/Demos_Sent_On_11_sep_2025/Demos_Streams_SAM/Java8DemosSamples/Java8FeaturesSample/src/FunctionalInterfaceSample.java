interface MyInterface1
{
	public void display();
}
interface MyInterface2
{
	public void calculate(int a, int b);
}
interface Customer
{
	public void calculateInvoiceAmt(int qty,int price);
}

interface NewCustomer
{
	public double calculateInvoice(int qty,int price);
}

interface SalesData
{
	public void calculateInvoice(int qty,int price,NewCustomer nc);
}
public class FunctionalInterfaceSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyInterface1 inter1 = () -> {
			
			System.out.println("Welcome to Functional Interfaces");
			System.out.println("And Implementations Through Lambda Expressions ");
		};
		
		MyInterface2 inter21 = (int a,int b) -> {
			
			int result = a + b;
			System.out.println("The sum is "+result);
		};
		
		MyInterface2 inter22 = (int a,int b) ->{
			 int result = a * b;
			 System.out.println("The Product is "+result);
		};

		
		inter1.display();
		inter21.calculate(100, 20);
		inter22.calculate(100,20);
		System.out.println("----------------------");
		Customer customer1 = (int qty, int price) -> {
			
			int invoiceAmt = qty * price;
			if(invoiceAmt >= 10000)
			{
				System.out.println(" Invoice Amt is "+invoiceAmt+" Good Purchase..");
			}
			else
			{
				System.out.println(" Invoice Amt is "+invoiceAmt+" Moderate Purchase..");
			}
			
		};
		customer1.calculateInvoiceAmt(100, 120);
		customer1.calculateInvoiceAmt(100, 50);
		System.out.println("----------------------------");
		NewCustomer nCustomer1 = (int qty, int price) -> {
			
			double invAmt = qty * price;
			double finalInvAmt = invAmt - (0.1 * invAmt);
			return finalInvAmt;
		};
		
		NewCustomer nCustomer2 = (int qty,int price) ->{
			double invAmt = qty * price;
			double finalInvAmt = invAmt - (0.2 * invAmt);
			return finalInvAmt;
		};
		System.out.println("-------------------------------");
		double customer1InvAmt = nCustomer1.calculateInvoice(1000, 100);
		System.out.println("The Invoice Amount for First Customer "+customer1InvAmt);
		
		double customer2InvAmt = nCustomer2.calculateInvoice(1000, 100);
		System.out.println("The Invoice Amount for Second Customer "+customer2InvAmt);
		
		System.out.println("-------------------------------");
		SalesData sd1 = (int qty , int price, NewCustomer nc) -> {
			
			double actInvoiceValue = qty * price;
			System.out.println("The Actual Invoice Value is "+actInvoiceValue);
			if(actInvoiceValue >= 100000)
			{
				System.out.println("Prime Customer");
			}
			else
			{
				System.out.println("Regular Customer ");
			}
			double discountedInvValue = nc.calculateInvoice(qty, price);
			System.out.println("The Discounted Invoice Value is "+discountedInvValue);
		};
		System.out.println("First Customer Details....");
		sd1.calculateInvoice(1000, 120, nCustomer1);
		System.out.println("Second Customer Details....");
		sd1.calculateInvoice(1000, 120, nCustomer2);
	}

}
