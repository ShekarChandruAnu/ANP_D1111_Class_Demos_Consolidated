import java.util.function.Function;
import java.util.function.Predicate;

public class FilterProgrammerOperation {

	public void filterProgrammers()
	{
		Function <Programmer,String> getProgrammerName = p->p.getName();
		
		
		Predicate <Programmer> isFemaleProgrammer = p-> p.isFemale();
		
		
		Programmer.programmers()
					.stream()
					.filter(Programmer::isFemale)
					.map(Programmer::getName)
					.forEach(System.out::println);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FilterProgrammerOperation fpo = new FilterProgrammerOperation();
		fpo.filterProgrammers();

	}

}
