interface Sayable2
{
	void say();
}
public class InstanceMethodReference {

	public void printMsg()
	{
		System.out.println("Hello , This is instance method accessed thru Thread..");
	}
	public void saySomething()
	{
		System.out.println("Hello, This is non static method");
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		InstanceMethodReference methodReference = new InstanceMethodReference();
		
		Sayable2 sayable = methodReference::saySomething;
		sayable.say();
		
		Sayable2 sayable1 = methodReference::saySomething;
		sayable1.say();
		
		Sayable2 sayable2 = new InstanceMethodReference()::saySomething;
		sayable2.say();
		
		
		Thread t2 = new Thread(new InstanceMethodReference()::printMsg);
		t2.start();

	}

}
