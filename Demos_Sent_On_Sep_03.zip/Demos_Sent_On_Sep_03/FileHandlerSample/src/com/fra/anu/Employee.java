package com.fra.anu;

import java.io.Serializable;

public class Employee implements Serializable{
	
	String employeeId;
	String employeeName;
	String employeeAddress;
	int employeeSalary;
	float employeeTax;
	
	public Employee() {
		super();
	}

	public Employee(String employeeId, String employeeName, String employeeAddress, int employeeSalary,
			float employeeTax) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.employeeSalary = employeeSalary;
		this.employeeTax = employeeTax;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeAddress() {
		return employeeAddress;
	}

	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}

	public int getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(int employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public float getEmployeeTax() {
		return employeeTax;
	}

	public void setEmployeeTax(float employeeTax) {
		this.employeeTax = employeeTax;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeAddress="
				+ employeeAddress + ", employeeSalary=" + employeeSalary + ", employeeTax=" + employeeTax + "]";
	}
	
	
	
	

}
