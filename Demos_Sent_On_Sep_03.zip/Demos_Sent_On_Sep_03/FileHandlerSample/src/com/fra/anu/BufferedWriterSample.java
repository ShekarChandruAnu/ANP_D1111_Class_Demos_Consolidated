package com.fra.anu;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriterSample {

	BufferedWriter bw;
	public void writeToFileThruBufferedWriter()
	{
		try {
			bw = new BufferedWriter(new FileWriter("Student.txt"));
			bw.write("we are writing character stream data to a file thru Buffer");
			bw.flush();
			bw.close();
			System.out.println("We have written successfully into the Character STream thru Buffer");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedWriterSample bws = new BufferedWriterSample();
		bws.writeToFileThruBufferedWriter();

	}

}
