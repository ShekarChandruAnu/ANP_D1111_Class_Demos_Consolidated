package com.fra.anu;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class SerializationSample {

	ObjectOutputStream ops;
	
	public void serializeEmployeeObjects()
	{
		ArrayList <Employee> employees = new ArrayList<Employee>();
		employees.add(new Employee("E001","Kiran","RTNagar",10000,12.34f));
		employees.add(new Employee("E002","Suman","Jayanagar",12000,13.34f));
		employees.add(new Employee("E003","Mathura","Vijayanagar",14000,11.34f));
		employees.add(new Employee("E004","Keerthana","Koramangala",16000,10.34f));
		employees.add(new Employee("E005","Madhu","Malleswaram",18000,14.34f));
		try {
			ops = new ObjectOutputStream(new FileOutputStream("Employee.txt"));
			ops.writeObject(employees);
			ops.flush();
			ops.close();
			System.out.println("We have Serialized Employee Objects Successfully");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SerializationSample sSample = new SerializationSample();
		sSample.serializeEmployeeObjects();

	}

}
