package com.fra.anu;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderSample {

	BufferedReader br;
	public void readFromFileThruBufferedReader()
	{
		try {
			br = new BufferedReader(new FileReader("Student.txt"));
			String readString = br.readLine();
			System.out.println("The Data that was read "+readString);
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedReaderSample brs = new BufferedReaderSample();
		brs.readFromFileThruBufferedReader();

	}

}
