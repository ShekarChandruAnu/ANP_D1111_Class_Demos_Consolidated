package com.fra.anu;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamSample {

	//Writing to Binary STream  -- OutputStream<----FileOutputStream
	FileOutputStream fos;
	byte[] mybytes = new byte[100];
	String str = "We are writing this content to a file thru Binary STream on 28 AUg 2025";
	public void writeToBinaryStream()
	{
		try {
			fos = new FileOutputStream("customer.txt");
			mybytes = str.getBytes();
			fos.write(mybytes);
			fos.flush();
			fos.close();
			System.out.println("We have written into a file thru Binary STream successfully");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileOutputStreamSample fops = new FileOutputStreamSample();
		fops.writeToBinaryStream();

	}

}
