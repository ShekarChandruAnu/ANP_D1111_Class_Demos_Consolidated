package com.fra.anu;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedOuputStreamSample {

	BufferedOutputStream bos;
	byte[] mybytes = new byte[100];
	String str1 = "We are writing this data through Buffer to a Binary STraem";
	public void writeThroughBufferedOutputStream()
	{
		try {
			bos = new BufferedOutputStream(new FileOutputStream("dealer.txt"));
			
		//	bos = new BufferedOutputStream(new FileOutputStream("dealer.txt"),100000);
			mybytes = str1.getBytes();
			bos.write(mybytes);
			bos.flush();
			bos.close();
			System.out.println("We have written into binary stream through buffer");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BufferedOuputStreamSample bStream = new BufferedOuputStreamSample();
		bStream.writeThroughBufferedOutputStream();
	}

}
