package com.fra.anu;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderSample {

	//str ="We are writing the Content to Char Stream";
	FileReader fr;
	public void readFromCharStream()
	{
		int myChar;
		// "c:\\folder1\\folder2\\file.txt"
		System.out.println("The Data Read from Character STream is");
		try {
			fr = new FileReader("Supplier.txt");
			while( (myChar=fr.read()) != -1)
			{
				System.out.print((char)myChar);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileReaderSample frs = new FileReaderSample();
		frs.readFromCharStream();

	}

}
