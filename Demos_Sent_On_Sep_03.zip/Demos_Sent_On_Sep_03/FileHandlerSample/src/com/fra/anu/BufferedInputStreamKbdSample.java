package com.fra.anu;

import java.io.BufferedInputStream;
import java.io.IOException;

public class BufferedInputStreamKbdSample {

	BufferedInputStream bis;
	byte[] mybytes = new byte[100];
	public void readFromStdInputFileThruBuffer()
	{
		bis = new BufferedInputStream(System.in);
		System.out.println("Please enter data to be read thru bufferedstream");
		try {
			bis.read(mybytes);
			String readStr = new String(mybytes);
			System.out.println("The Data read from Keyboard is "+readStr);
			bis.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedInputStreamKbdSample biKbd = new BufferedInputStreamKbdSample();
		biKbd.readFromStdInputFileThruBuffer();
	}

}
