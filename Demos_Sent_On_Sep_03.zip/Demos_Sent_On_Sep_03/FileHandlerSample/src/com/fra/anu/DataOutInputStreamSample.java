package com.fra.anu;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataOutInputStreamSample {

	DataOutputStream dos;
	DataInputStream dis;
	public void writeToFileUsingDataOutputStream()
	{
		try {
			dos = new DataOutputStream(new FileOutputStream("products.txt"));
			dos.writeFloat(2345.678f);
			dos.writeInt(20000);
			dos.writeBoolean(true);
			dos.writeUTF("We are writing aString"); // Universal Transaction/Transform Set Form
			//UTF-8 UTF-16 UTF32 UTF64  char 16 bits  encoding systems
			dos.flush();
			dos.close();
			System.out.println("The Data is written into DataOutputStream successfully");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
	}
	public void readFromFileUsingDataInputStream()
	{
		try {
			dis = new DataInputStream(new FileInputStream("products.txt"));
			System.out.println("The Float Data That was read "+dis.readFloat());
			System.out.println("The Int data that was read "+dis.readInt());
			System.out.println("The Boolean Data that was read "+dis.readBoolean());
			System.out.println("The String data that was "+dis.readUTF());
			dis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DataOutInputStreamSample doStream = new DataOutInputStreamSample();
		//doStream.writeToFileUsingDataOutputStream();
		doStream.readFromFileUsingDataInputStream();

	}

}
