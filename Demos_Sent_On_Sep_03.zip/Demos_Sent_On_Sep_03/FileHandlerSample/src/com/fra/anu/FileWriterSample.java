package com.fra.anu;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterSample {

	FileWriter fw;
	String str ="We are writing the Content to Char Stream Aug 29";
	public void writeToCharStream()
	{
		try {
			fw = new FileWriter("Supplier.txt");
			fw.write(str);
			fw.flush();
			fw.close();
			System.out.println("We wrote the character-String data into Character Stream ");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileWriterSample fws = new FileWriterSample();
		fws.writeToCharStream();

	}

}
