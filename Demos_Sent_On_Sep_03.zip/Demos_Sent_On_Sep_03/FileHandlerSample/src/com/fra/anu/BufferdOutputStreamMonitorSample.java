package com.fra.anu;

import java.io.BufferedOutputStream;
import java.io.IOException;

public class BufferdOutputStreamMonitorSample {

	BufferedOutputStream bos;
	byte[] mybytes= new byte[100];
	String str = "we are writing to Std O/p file- monitor thru Buffer";
	public void writeToStdOutputFileThruBuffer()
	{
		//bos = new BufferdOutputStream(new FileOutputStream("cust.txt"));
		//bos = new BufferedOutputStream(new PrintStream("monitor");
		/* class System
		{
			static PrintStream out
			
		}
		System sys = new System();
		sys.out
		
		*/
		mybytes = str.getBytes();
		// Representing O/PStream that goes to STd op file i.e monitor 
		bos = new BufferedOutputStream(System.out);
		try 
		{
			bos.write(mybytes);
			bos.flush();
			System.out.println("We have written the data onto Monitor");
			bos.close();
			System.out.println("We have written the data onto Monitor");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferdOutputStreamMonitorSample boStream = new BufferdOutputStreamMonitorSample();
		boStream.writeToStdOutputFileThruBuffer();

	}

}
