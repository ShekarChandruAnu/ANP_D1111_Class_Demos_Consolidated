package com.fra.anu;

public abstract class Shape {

	public abstract void calculateArea(double side);
	public void displayArea()
	{
		System.out.println("Displaying Area");
	}
	
}

