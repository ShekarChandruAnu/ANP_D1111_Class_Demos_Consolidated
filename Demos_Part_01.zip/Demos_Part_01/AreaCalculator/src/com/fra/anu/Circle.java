package com.fra.anu;

public class Circle extends Shape{
	double area;
	@Override
	public void calculateArea(double side) {
		// TODO Auto-generated method stub
		area = 3.14 * side * side;
	}
	public void displayArea()
	{
		System.out.println("The Area of Circle is "+area);
	}
}
