package com.fra.anu;

public class Square extends Shape{

	double area;
	@Override
	public void calculateArea(double side) {
		// TODO Auto-generated method stub
		 area = side * side;
	}
	public void displayArea()
	{
		System.out.println("The Area of Square is "+area);
	}

}
