package com.fra.anu;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape shape;
		System.out.println("Calling Area of Square ");
		shape = new Square();
		shape.calculateArea(20.0);
		shape.displayArea();
		
		System.out.println("Calling Area of Rectangle");
		shape = new Rectangle();
		shape.calculateArea(10.0);
		shape.displayArea();
		
		System.out.println("Calling Area of Triangle");
		shape = new Triangle();
		shape.calculateArea(15.0);
		shape.displayArea();
		
		System.out.println("Calling Area of Circle");
		shape = new Circle();
		shape.calculateArea(25.0);
		shape.displayArea();
		
		
		
		

	}

}
