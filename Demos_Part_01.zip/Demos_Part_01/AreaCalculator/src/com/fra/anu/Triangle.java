package com.fra.anu;

public class Triangle extends Shape {

	double area;
	@Override
	public void calculateArea(double side) {
		// TODO Auto-generated method stub
		area = 0.5 * side * 1.5 * side;
	}
	public void displayArea()
	{
		System.out.println("The Area of Triangle is "+area);
	}
}
