package com.fra.anu;

public class Rectangle extends Shape{

	double area;
	@Override
	public void calculateArea(double side) {
		// TODO Auto-generated method stub
		area = side * 1.5 * (side);
	}
	public void displayArea()
	{
		System.out.println("The Area of Rectangle is "+area);
	}
}
