package com.fra.anu;

public interface Account extends CreditCardAcct,DebitCardAcct{
	
	public void openAccount();
	public void closeAccount();

}
