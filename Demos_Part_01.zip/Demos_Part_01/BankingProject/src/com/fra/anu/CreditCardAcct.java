package com.fra.anu;

public interface CreditCardAcct {

	public void calculateOutstandingAmt();
	public void calculateRedemptionPoints();
}
