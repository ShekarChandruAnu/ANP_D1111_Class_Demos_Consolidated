package com.fra.anu;

public interface DebitCardAcct {

	public void depositAmount();
	public void withdrawAmount();
	public void checkBalance();
}
