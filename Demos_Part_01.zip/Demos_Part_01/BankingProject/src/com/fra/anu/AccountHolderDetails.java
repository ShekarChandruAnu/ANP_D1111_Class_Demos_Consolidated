package com.fra.anu;

import java.util.Scanner;

public class AccountHolderDetails {

	String actHolderName;
	String actHolderAddress;
	String occupation;
	String aadharCardNumber;
	Scanner scan1;
	public AccountHolderDetails()
	{
		scan1 = new Scanner(System.in);
	}
	public void getAccountHolderDetails()
	{
		System.out.println("Enter the Account Holder Details...");
		System.out.println("Enter Acct Holder Name");
		actHolderName = scan1.next();
		
		System.out.println("Enter Acct Holder Address");
		actHolderAddress = scan1.next();
		
		System.out.println("Enter Acct Holder occupation");
		occupation = scan1.next();
		
		System.out.println("Enter Acct Holder aadharCardNumber");
		aadharCardNumber = scan1.next();
	}
	public void displayAccountHolderDetails()
	{
		System.out.println("--------Account Holder Details are------");
		System.out.println("Account Holder Name "+actHolderName);
		System.out.println("Account Holder Address "+actHolderAddress);
		System.out.println("Account Holder occupation "+occupation);
		System.out.println("Account Holder aadharCardNumber "+aadharCardNumber);
	}
}
