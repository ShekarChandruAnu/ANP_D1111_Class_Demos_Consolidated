package com.fra.anu;

public class MyAccount extends AccountHolderDetails implements Account,InsuranceAccount{

	@Override
	public void calculateOutstandingAmt() {
		// TODO Auto-generated method stub
		System.out.println("Calculated Outstanding AMT....");
	}

	@Override
	public void calculateRedemptionPoints() {
		// TODO Auto-generated method stub
		System.out.println("Calculated Redemption Points....");
	}

	@Override
	public void depositAmount() {
		// TODO Auto-generated method stub
		System.out.println("Deposited Amount..successfully..");
	}

	@Override
	public void withdrawAmount() {
		// TODO Auto-generated method stub
		System.out.println("Amount..Withdrawn successfully...");
	}

	@Override
	public void checkBalance() {
		// TODO Auto-generated method stub
		System.out.println("Balance is ...");
	}

	@Override
	public void calculatePremium() {
		// TODO Auto-generated method stub
		System.out.println("Calculated Premium ....");
	}

	@Override
	public void payPremium() {
		// TODO Auto-generated method stub
		System.out.println("Paid Premium Successfully..");
	}

	@Override
	public void openAccount() {
		// TODO Auto-generated method stub
		System.out.println("Account Opened Successfully...");
	}

	@Override
	public void closeAccount() {
		// TODO Auto-generated method stub
		System.out.println("Account Closed Successfully...");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyAccount mact = new MyAccount();
		mact.openAccount();
		//CreditCard Details
		mact.calculateOutstandingAmt();
		mact.calculateRedemptionPoints();
		//DebitCard Details
		mact.checkBalance();
		mact.depositAmount();
		mact.withdrawAmount();
		//Insurance Acct
		mact.calculatePremium();
		mact.payPremium();
		mact.getAccountHolderDetails();
		mact.displayAccountHolderDetails();
		mact.closeAccount();

	}


}
