package com.fra.anu;

public abstract class Shape {
	
	public abstract void calculateArea(double side);
	

}
