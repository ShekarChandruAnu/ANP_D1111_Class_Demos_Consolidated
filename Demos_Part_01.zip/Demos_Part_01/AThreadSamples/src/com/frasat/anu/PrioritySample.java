package com.frasat.anu;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class MyThread implements Runnable
{
	Thread t1;
	public MyThread(int priority)
	{
		t1 = new Thread(this,"Current Thread");
		t1.setPriority(priority);
		System.out.println("Child Thread "+t1);
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<5;i++)
		{
			System.out.println(t1+" Loop "+(i+1));
			try {
				t1.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}
public class PrioritySample {
	
		public static void main(String[] args)
		{
			// 8 6 2
			MyThread mt1 = new MyThread(Thread.NORM_PRIORITY+3);
			MyThread mt2 = new MyThread(Thread.NORM_PRIORITY+1);
			MyThread mt3 = new MyThread(Thread.NORM_PRIORITY-3);
			
			Lock lock = new ReentrantLock();
			lock.lock();
				mt3.t1.start();
			lock.unlock();
			
			lock.lock();
				mt1.t1.start();
			lock.unlock();
			
			lock.lock();
				mt2.t1.start();
			lock.unlock();

		}

}
