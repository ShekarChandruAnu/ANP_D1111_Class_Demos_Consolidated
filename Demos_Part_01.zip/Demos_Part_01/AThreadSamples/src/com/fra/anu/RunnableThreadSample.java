package com.fra.anu;
class MyThread implements Runnable
{
	Thread t1;
	public MyThread()
	{
		t1 = new Thread(this,"Child Thread");
		System.out.println(t1);
		t1.start();
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Entered the Child Thread Functionality....");
		System.out.println("AMidst The Child Thread Functionality....");
		System.out.println("Exiting the Child Thread");
		
	}	
}
public class RunnableThreadSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In the Main Thread....");
		System.out.println("About to Invoke Child Thread...");
		MyThread mt1 = new MyThread();//UNSTARTED // RUNNABLE // RUNNING NOT RUNNABLE
		System.out.println("Exiting The Main Thread....");


}

}
