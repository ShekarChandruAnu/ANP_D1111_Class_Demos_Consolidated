package com.fra.anu;
class Thread1
{
	public /*synchronized */ void producenConsume()
	{
		System.out.println("Produce Goods.......");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Produced , Ready to be Consumed---Consuming");
	}
}
class MyThreadSynch extends Thread
{
	Thread1 t1;
	public MyThreadSynch(Thread1 t1)
	{
		this.t1 = t1;
	}
	public void run()
	{
		synchronized(t1)
		{
			t1.producenConsume();
			
		}
		
		//
		//
		//
		//
	}
	
}
public class NonSynchronizedSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread1 th1 = new Thread1();
		MyThreadSynch mts1 = new MyThreadSynch(th1);
		MyThreadSynch mts2 = new MyThreadSynch(th1);
		MyThreadSynch mts3 = new MyThreadSynch(th1);
		
		mts1.start();
		mts2.start();
		mts3.start();

	}

}
