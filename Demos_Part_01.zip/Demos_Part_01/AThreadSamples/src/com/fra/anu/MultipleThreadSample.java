package com.fra.anu;
class MyThreadClass implements Runnable
{
	String threadName;
	Thread t1 ;
	public MyThreadClass(String threadName)
	{
		this.threadName = threadName;
		t1 = new Thread(this,threadName);
		t1.start();
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("In the Child Thread"+threadName);
		for(int i=0;i<5;i++)
		{
			System.out.println(threadName+" Loop "+(i+1));
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
}
public class MultipleThreadSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In The Main Thread....");
		System.out.println("exiting The Main Thread..");
		MyThreadClass mtc1 = new MyThreadClass("First Child Thread");
		MyThreadClass mtc2 = new MyThreadClass("Second Child Thread");
		MyThreadClass mtc3 = new MyThreadClass("Third Child Thread");
		for(int i=0;i<5;i++)
		{
			System.out.println("Main Thread Loop "+(i+1));
			try {
				Thread.sleep(1500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Exiting Main Thread...");
	}

}
