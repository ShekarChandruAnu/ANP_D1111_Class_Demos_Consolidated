package com.fra.anu;
class MyThread1 implements Runnable
{
	Thread t1;
	public MyThread1()
	{
		t1 = new Thread(this,"Child Thread");
		t1.start();
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Entering The Child Thread..");
		for(int i=0;i<5;i++)
		{
			System.out.println("Child Thread Loop "+(i+1));
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("Exiting the Child Thread");
		
	}	
}
public class RunnableThreadSample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Entering the Main Thread");
		System.out.println("About to Invoke Child Thread...");
		MyThread1 mt1 = new MyThread1();
		System.out.println("Is The Child Thread Alive ? "+mt1.t1.isAlive());
		System.out.println("Child Thread Made to Join the Main Thread");
		try {
			mt1.t1.join();
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		for(int i=0;i<5;i++)
		{
			System.out.println("Main Thread Loop "+(i+1));
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Is The Child Thread still Alive ? "+mt1.t1.isAlive());
		System.out.println("Exiting The Child Thread...");



}

}
