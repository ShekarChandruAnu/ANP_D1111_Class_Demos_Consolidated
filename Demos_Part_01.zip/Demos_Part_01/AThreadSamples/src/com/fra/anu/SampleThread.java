package com.fra.anu;

public class SampleThread {
//1       10
	// MAX_PRIORITY -- 10
	//MIN_PRIORITY -- 1   4 -- 10     4 -- 5    4  -- 2
	//NORM_PRIORITY -- 5
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread myThread = Thread.currentThread();
		System.out.println("Current Thread "+myThread);
		myThread.setName("Current New Thread");
		System.out.println("Thread AFter Name Change "+myThread);

	}

}
