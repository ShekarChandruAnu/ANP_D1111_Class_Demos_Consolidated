package com.fra.anu;

public class CallByValue {

	//CALLED FUNCTION
	public void swap(int num1,int num2)
	{
		int temp;
		temp = num1;
		num1 = num2;
		num2 = temp;
		System.out.println("Num1 after swapping  "+num1); //200
		System.out.println("Num2 After swapping "+num2); //100
	}
	//CALLING FUNCTION
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 100;
		int y = 200;
		CallByValue cbv = new CallByValue();
		System.out.println("Value of X before swapping "+x); // 100
		System.out.println("Value of y before swapping "+y); //200
		cbv.swap(x, y);
		System.out.println("Value of X after swapping in the calling method "+x); 
		System.out.println("Value of y after swapping in the calling method"+y); 

	}

}
