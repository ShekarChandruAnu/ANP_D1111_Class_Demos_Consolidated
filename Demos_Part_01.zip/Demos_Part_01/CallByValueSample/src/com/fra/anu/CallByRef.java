package com.fra.anu;
class RefObject
{
	int score;
	public RefObject(int score)
	{
		this.score = score;
	}
	
}

public class CallByRef {
	public void calledMethod(RefObject ref)
	{
		ref.score+=10; //arithmetic assignment operator
		System.out.println("The Score in CalledMethod is "+ref.score);//85
	}
	public void callingMethod()
	{
		RefObject ro = new RefObject(75);//score is 75
		System.out.println("The Value of Score in Calling Method before calling "+ro.score);//75
		calledMethod(ro); //85
		System.out.println("The Value of Score in Calling Method after calling "+ro.score);//85
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CallByRef cbr = new CallByRef();
		cbr.callingMethod();

	}

}
