package com.fra.anu;

import java.util.Scanner;

public class AccountHolderDetail {
	
	String acctHolderName;
	String address;
	String occupation;
	String aadharNumber;
	//Creating and initializing Scanner Object
	Scanner scan = new Scanner(System.in);
	//Constructor to initialize Data Members
	public AccountHolderDetail()
	{
		
	}
	//Method to accept AccountHolder Details
	public void getAccountHolderDetails()
	{
		System.out.println("Enter Account Holder Name");
		acctHolderName = scan.next();
		
		System.out.println("Enter Address");
		address = scan.next();
		
		System.out.println("Enter Occupation");
		occupation = scan.next();
		
		System.out.println("Enter Aadhar Number");
		aadharNumber = scan.next();
		
	}
	public void displayActHolderDetails()
	{
		System.out.println("The Acct Holder Details are");
		System.out.println("The Account Holder Name "+acctHolderName);
		System.out.println("The Account Holder Address "+address);
		System.out.println("The Account Holder Occupation "+occupation);
		System.out.println("The Account Holder's KYC Detail "+aadharNumber);
	}
}
