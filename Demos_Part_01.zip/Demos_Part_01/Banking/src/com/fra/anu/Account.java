package com.fra.anu;

public interface Account extends CreditCardAct,DebitCardAct{

	public void openAccount();
	public void closeAccount();
}
