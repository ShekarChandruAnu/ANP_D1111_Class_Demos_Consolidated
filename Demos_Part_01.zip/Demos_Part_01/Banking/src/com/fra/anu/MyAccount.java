package com.fra.anu;

public class MyAccount extends AccountHolderDetail implements Account,InsuranceAccount {

	@Override
	public void calculateOutstandingAmt() {
		// TODO Auto-generated method stub
		System.out.println("Outstanding Amount is ");
	}

	@Override
	public void calculateRedemptionPoints() {
		// TODO Auto-generated method stub
		System.out.println("The Redemption Points You gained is ");
	}

	@Override
	public void depositAmount() {
		// TODO Auto-generated method stub
		System.out.println("Deposited AMnount Successfully");
		
	}

	@Override
	public void withdrawAmount() {
		// TODO Auto-generated method stub
		System.out.println("Withdrawal SUccessful...");
		
	}

	@Override
	public void checkBalance() {
		// TODO Auto-generated method stub
		System.out.println("Balance is ... ");
		
	}

	@Override
	public void calculatePremium() {
		// TODO Auto-generated method stub
		System.out.println("Calculated Premium Is ...");
		
	}

	@Override
	public void payPremium() {
		// TODO Auto-generated method stub
		System.out.println("Premium Paid Successfully...");
		
	}

	@Override
	public void openAccount() {
		// TODO Auto-generated method stub
		System.out.println("Account Opened Successfully...");
		
	}

	@Override
	public void closeAccount() {
		// TODO Auto-generated method stub
		System.out.println("Account Closed");
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyAccount account1 = new MyAccount();
		account1.openAccount();
		account1.depositAmount();
		account1.checkBalance();
		account1.withdrawAmount();
		account1.checkBalance();
		System.out.println("Credit Card Details");
		account1.calculateOutstandingAmt();
		account1.calculateRedemptionPoints();
		account1.calculatePremium();
		account1.payPremium();
		account1.getAccountHolderDetails();
		account1.displayActHolderDetails();
		account1.calculateOutstandingAmt();
		
		
		
		account1.closeAccount();

	}

}
