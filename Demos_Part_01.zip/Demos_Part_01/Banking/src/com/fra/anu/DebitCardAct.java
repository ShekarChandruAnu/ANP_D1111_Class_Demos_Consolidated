package com.fra.anu;

public interface DebitCardAct {

	public void depositAmount();
	public void withdrawAmount();
	public void checkBalance();
}
