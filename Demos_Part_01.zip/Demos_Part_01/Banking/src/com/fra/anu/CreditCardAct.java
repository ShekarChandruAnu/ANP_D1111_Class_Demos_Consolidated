package com.fra.anu;

public interface CreditCardAct {

	public void calculateOutstandingAmt();
	public void calculateRedemptionPoints();
}
