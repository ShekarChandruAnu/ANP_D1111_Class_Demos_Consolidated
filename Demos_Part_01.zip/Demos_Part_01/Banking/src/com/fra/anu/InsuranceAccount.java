package com.fra.anu;

public interface InsuranceAccount {

	public void calculatePremium();
	public void payPremium();
}
