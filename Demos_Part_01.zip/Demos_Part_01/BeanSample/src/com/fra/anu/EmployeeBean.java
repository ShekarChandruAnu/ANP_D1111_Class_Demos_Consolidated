package com.fra.anu;

//BEAN CLASS - PLAIN OLD JAVA OBJECT
public class EmployeeBean {
	
	//PRIVATE DATA MEMBERS
	private String employeeId;
	private String employeeName;
	private String employeeAddress;
	private String employeePhone;
	private int employeeSalary;
	
	
	//CONSTRUCTORS DEFAULT
	public EmployeeBean() {
		super();
	}
	
	//PARAMETERIZED CONSTRUCTORS
	public EmployeeBean(String employeeId, String employeeName, String employeeAddress, String employeePhone,
			int employeeSalary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.employeePhone = employeePhone;
		this.employeeSalary = employeeSalary;
	}

	//GETTERS & SETTERS

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmployeeAddress() {
		return employeeAddress;
	}

	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}

	public String getEmployeePhone() {
		return employeePhone;
	}

	public void setEmployeePhone(String employeePhone) {
		this.employeePhone = employeePhone;
	}

	public int getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(int employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	//TOSTRING


	@Override
	public String toString() {
		return "EmployeeBean [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeAddress="
				+ employeeAddress + ", employeePhone=" + employeePhone + ", employeeSalary=" + employeeSalary + "]";
	}
	
	
	
	
	
	
	
	
}
