package com.fra.anu;

public class SwitcherSample {

	public void switchDay(int day)
	{
		switch (day)
		{
			case 1:
			{
				System.out.println("Day is Monday...");
				break;
			}
			case 2:
			{
				System.out.println("Day is Tuesday...");
				break;
			}
			case 3:
			{
				System.out.println("Day is Wednesday...");
				break;
			}
			case 4:
			{
				System.out.println("Day is Thursday...");
				break;
			}
			case 5:
			{
				System.out.println("Day is Friday...");
				break;
			}
			case 6:
			{
				System.out.println("Day is Saturday...");
				break;
			}
			case 7:
			{
				System.out.println("Day is Sunday...");
				break;
			}
			default:
			{
				System.out.println("Sorry Valid Range is 1 -7 ..");
				break;
			
			}
		} // SWITCH ENDS HERE
		System.out.println("We are outside switch construct");
	}
	
	public void showTernarySample()
	{
		int score = 45;
		String result = (score >= 50)?"GREAT PASSED!!!":"SORRY TRY AGAIN";
		System.out.println(result);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwitcherSample ss = new SwitcherSample();
	/*	ss.switchDay(5);
		ss.switchDay(4);
		ss.switchDay(3);
		ss.switchDay(2);
		ss.switchDay(532);*/
		ss.showTernarySample();
		
		

	}

}
