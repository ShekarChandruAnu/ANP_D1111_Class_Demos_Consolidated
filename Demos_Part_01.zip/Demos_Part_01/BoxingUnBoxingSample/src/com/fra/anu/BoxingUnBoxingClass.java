package com.fra.anu;

public class BoxingUnBoxingClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Object obj = new Object() ;
		int num1 = 1000;
		System.out.println("The Value type in its Original Form "+num1);
		obj = num1; // BOXING -IMPLICIT
		System.out.println("The Value Type Converted to reference Type Object "+obj);

		//------------- SOME MODULE DID ABOVE PART WHICH IS BEING USED IN THE FOLLOWING MODULE
		
		int myObjectValue = (int)obj;// Reference type to value type UNBOXING
		
	}

}
