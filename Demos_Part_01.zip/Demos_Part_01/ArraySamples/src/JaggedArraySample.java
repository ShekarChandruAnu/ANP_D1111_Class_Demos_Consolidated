
public class JaggedArraySample {

	int jarr[][] = new int[3][]; // DECLARING THE JAGGED ARRAY
	
	
	public void populateJaggedArray()
	{
		jarr[0] = new int[5];
		jarr[1] = new int[3];
		jarr[2] = new int[6];
		
		for(int i=0;i<5;i++)
		{
			jarr[0][i] = (i+1)*10;
		}
		for(int j=0;j<3;j++)
		{
			jarr[1][j] = (j+1)*100;
		}
		for(int k=0;k<6;k++)
		{
			jarr[2][k] = (k+1)*1000;
		}
	}
	public void displayJaggedArrayValues()
	{
		for(int i=0;i<5;i++)
		{
			System.out.print(jarr[0][i]+" ");
		}
		System.out.println();
		for(int j=0;j<3;j++)
		{
			System.out.print(jarr[1][j]+" ");
		}
		System.out.println();
		for(int k=0;k<6;k++)
		{
			System.out.print(jarr[2][k]+" ");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JaggedArraySample jars = new JaggedArraySample();
		jars.populateJaggedArray();
		jars.displayJaggedArrayValues();
	}

}
