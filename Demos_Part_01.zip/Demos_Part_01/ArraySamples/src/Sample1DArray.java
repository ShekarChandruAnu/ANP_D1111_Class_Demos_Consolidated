import java.util.Scanner;

public class Sample1DArray {
	// ctrl+shift+o
	int scores[] = new int[10];
	Scanner scan1 = new Scanner(System.in);

	// Method to Initialize single Dimensional Array
	
	public void manipulate1DArray()
	{
		for(int i=0;i<10;i++)
		{
			System.out.println("Enter the "+(i+1)+" Score");
			scores[i] = scan1.nextInt();
		}
		
	}
	public void displayScores()
	{
		for(int i=0;i<10;i++)
		{
			System.out.println("The "+(i+1)+" Score is "+scores[i]);
		}
		System.out.println("Using length property");
		for(int i=0;i<scores.length;i++)
		{
			System.out.println("The "+(i+1)+" Score is "+scores[i]);
		}
		System.out.println("--------FAST ENUMERATION-------------");
		for(int x:scores) // FOR EACH 
		{
			System.out.println("Score is "+x);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample1DArray sam1 = new Sample1DArray();
		sam1.manipulate1DArray();
		sam1.displayScores();

	}

}
