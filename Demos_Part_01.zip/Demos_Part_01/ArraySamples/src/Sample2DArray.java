
public class Sample2DArray {

	int[][] values = new int[3][5];
	
	public void populate2DArray()
	{
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<5;j++)
			{
				values[i][j] = (i+j)*10;
			}
			
		}
	}
	public void display2DArrayValues()
	{
		for(int k=0;k<3;k++)
		{
			for(int l=0;l<5;l++)
			{
				System.out.print(values[k][l]+" ");
			}
			System.out.println("-----");
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample2DArray s2d = new Sample2DArray();
		s2d.populate2DArray();
		s2d.display2DArrayValues();

	}

}
